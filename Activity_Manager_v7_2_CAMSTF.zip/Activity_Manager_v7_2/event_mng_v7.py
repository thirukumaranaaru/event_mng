#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Activity Manager v7.2. GUI mode: python event_mng_v7.py | Scheduled mode: --run

Outlook sending uses the v5-compatible default-account path when AdminMailID
is the default/only Outlook account; SendUsingAccount is used only for a
non-default account. Outlook COM failures are logged with the failing stage.
"""
from __future__ import annotations

import argparse
import datetime as dt
import logging
import re
import sys
import os
import subprocess
from pathlib import Path
from typing import Any

import openpyxl
try:
    import win32com.client
except ImportError:
    win32com = None
try:
    from win10toast import ToastNotifier
except ImportError:
    ToastNotifier = None
try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:
    tk = None
try:
    from PIL import Image, ImageTk, ImageEnhance, ImageDraw, ImageFont
except ImportError:
    Image = ImageTk = ImageEnhance = ImageDraw = ImageFont = None

APP_DIR = Path(__file__).resolve().parent
WORKBOOK_PATH = APP_DIR / "ActivityList.xlsx"
LOG_PATH = APP_DIR / "reminder_log.txt"
SHEET = "Activities"
TEAM_LOGO_PATH = APP_DIR / "team_logo.png"
COMPANY_LOGO_PATH = APP_DIR / "company_logo.png"
HEADERS = [
    "ActivityID", "Description", "DueDate", "ReminderDate", "AssignedTo",
    "RemindedStatus", "ManagerEmail", "DailyReminderStartDate", "AdminMailID",
    "LastReminderDate", "LastNotified", "CompletionStatus",
]
STATUSES = {
    "completed": "Completed",
    "not completed yet": "Not Completed Yet",
    "in progress": "In Progress",
    "delayed": "Delayed",
}
DATE_ONLY = {"ReminderDate", "DailyReminderStartDate", "LastReminderDate", "LastNotified"}


def setup_log() -> None:
    logging.basicConfig(
        filename=LOG_PATH, level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s", encoding="utf-8",
    )


def log(message: str, level: int = logging.INFO) -> None:
    logging.log(level, message)
    print(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} - {message}")


def as_date(value: Any) -> dt.date | None:
    if value is None or str(value).strip() == "":
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    for fmt in ("%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y", "%Y/%m/%d"):
        try:
            return dt.datetime.strptime(str(value).strip(), fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Invalid date {value!r}; use DD-MM-YYYY.")


def as_due_datetime(value: Any) -> dt.datetime | None:
    if value is None or str(value).strip() == "":
        return None
    if isinstance(value, dt.datetime):
        return value
    if isinstance(value, dt.date):
        return dt.datetime.combine(value, dt.time.min)
    for fmt in ("%d-%m-%Y %H:%M", "%d-%m-%Y %H:%M:%S", "%d-%m-%Y",
                "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return dt.datetime.strptime(str(value).strip(), fmt)
        except ValueError:
            continue
    raise ValueError(f"Invalid DueDate {value!r}; use DD-MM-YYYY HH:MM.")


def split_emails(value: Any) -> list[str]:
    return [part.strip() for part in re.split(r"[;,]", str(value or "")) if part.strip()]


def style_sheet(ws) -> None:
    from openpyxl.styles import Font, PatternFill, Alignment
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:L{max(1, ws.max_row)}"
    for col, width in enumerate([12, 30, 22, 16, 32, 16, 32, 22, 32, 18, 18, 22], 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width
    # Format only existing data rows. Pre-creating hundreds of blank rows would
    # make Excel's append operation place new activities hundreds of rows down.
    for row in range(2, ws.max_row + 1):
        ws.cell(row, 3).number_format = "dd-mm-yyyy hh:mm"
        for col in (4, 8, 10, 11):
            ws.cell(row, col).number_format = "dd-mm-yyyy"


def ensure_schema() -> None:
    """Create the workbook if absent; migrate old headers only when necessary."""
    if not WORKBOOK_PATH.exists():
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = SHEET
        ws.append(HEADERS)
        style_sheet(ws)
        wb.save(WORKBOOK_PATH)
        return

    wb = openpyxl.load_workbook(WORKBOOK_PATH)
    ws = wb[SHEET] if SHEET in wb.sheetnames else wb.create_sheet(SHEET)
    # Older v6 templates preformatted hundreds of blank rows. Remove only empty
    # trailing rows so GUI Add appends immediately below the real records.
    original_max_row = ws.max_row
    while ws.max_row > 1 and all(ws.cell(ws.max_row, col).value is None for col in range(1, ws.max_column + 1)):
        ws.delete_rows(ws.max_row, 1)
    trimmed_blank_rows = ws.max_row != original_max_row
    current = [str(ws.cell(1, c).value or "").strip() for c in range(1, ws.max_column + 1)]
    if current[:len(HEADERS)] == HEADERS and all(not x for x in current[len(HEADERS):]):
        # Normal case: do not rewrite/rebuild the data rows on every run.
        if ws.max_column != len(HEADERS):
            for c in range(ws.max_column, len(HEADERS), -1):
                ws.delete_cols(c)
        if trimmed_blank_rows or ws.max_column != len(HEADERS):
            style_sheet(ws)
            wb.save(WORKBOOK_PATH)
        return

    rename = {"Status": "RemindedStatus"}
    normalized = [rename.get(name, name) for name in current]
    positions = {name: index + 1 for index, name in enumerate(normalized) if name}
    # Do not reinterpret old NotifyPeriodDays (a number) as a calendar date.
    for obsolete in ("ReminderDaysBefore", "NotifyPeriodDays"):
        positions.pop(obsolete, None)
    rows = []
    for row_num in range(2, ws.max_row + 1):
        values = [ws.cell(row_num, positions[h]).value if h in positions else None for h in HEADERS]
        if any(value is not None and str(value).strip() for value in values):
            rows.append(values)
    ws.delete_rows(1, ws.max_row)
    ws.append(HEADERS)
    for row in rows:
        ws.append(row)
    style_sheet(ws)
    wb.save(WORKBOOK_PATH)
    log("Workbook columns were migrated to the v7 format. Please review the records in the GUI.")


def load_rows() -> list[dict[str, Any]]:
    ensure_schema()
    wb = openpyxl.load_workbook(WORKBOOK_PATH)
    ws = wb[SHEET]
    rows: list[dict[str, Any]] = []
    for row_num in range(2, ws.max_row + 1):
        item = {header: ws.cell(row_num, col).value for col, header in enumerate(HEADERS, 1)}
        if any(value is not None and str(value).strip() for value in item.values()):
            item["_row"] = row_num
            rows.append(item)
    return rows


def save_rows(rows: list[dict[str, Any]]) -> None:
    wb = openpyxl.load_workbook(WORKBOOK_PATH)
    ws = wb[SHEET]
    for item in rows:
        row_num = item["_row"]
        for col, header in enumerate(HEADERS, 1):
            ws.cell(row_num, col).value = item.get(header)
        ws.cell(row_num, 3).number_format = "dd-mm-yyyy hh:mm"
        for col in (4, 8, 10, 11):
            ws.cell(row_num, col).number_format = "dd-mm-yyyy"
    wb.save(WORKBOOK_PATH)


def outlook_app():
    if win32com is None:
        raise RuntimeError("pywin32 is missing. Outlook integration requires Windows and Classic Outlook.")
    return win32com.client.Dispatch("Outlook.Application")


def outlook_account(app, admin_mail_id: str):
    wanted = admin_mail_id.strip().casefold()
    accounts = app.Session.Accounts
    for index in range(1, accounts.Count + 1):
        account = accounts.Item(index)
        smtp = str(getattr(account, "SmtpAddress", "") or "").strip().casefold()
        if smtp == wanted:
            return account
    raise RuntimeError(f"AdminMailID '{admin_mail_id}' is not configured as an account in this Outlook profile.")


def _account_is_default(app, account) -> bool | None:
    """Return True/False when Outlook exposes comparable delivery stores; else None."""
    try:
        default_store_id = str(app.Session.DefaultStore.StoreID)
        account_store_id = str(account.DeliveryStore.StoreID)
        return bool(default_store_id and account_store_id and default_store_id == account_store_id)
    except Exception:
        return None


def send_mail(admin_mail_id: str, to_value: str, cc_value: str, subject: str, body: str) -> bool:
    """Send mail using the v5-compatible default-account path where possible.

    If AdminMailID is the Outlook profile's default account (or the only
    configured account), do not set MailItem.SendUsingAccount. The earlier
    v5 implementation successfully used CreateItem -> To/Subject/Body -> Send.
    For a non-default account, SendUsingAccount remains necessary and is used
    explicitly. Each COM stage is logged so a failure can be diagnosed.
    """
    stage = "starting"
    try:
        stage = "connect to Outlook.Application"
        app = win32com.client.Dispatch("Outlook.Application")
        stage = "find AdminMailID account"
        account = outlook_account(app, admin_mail_id)
        wanted = admin_mail_id.strip().casefold()

        stage = "read Outlook account collection"
        accounts = app.Session.Accounts
        account_count = int(accounts.Count)
        is_default = _account_is_default(app, account)
        use_default_send_path = is_default is True or (is_default is None and account_count == 1)

        stage = "parse To recipients"
        recipients = split_emails(to_value)
        if not recipients:
            raise ValueError("AssignedTo is blank.")
        cc_recipients = split_emails(cc_value)

        # Match the working v5 send sequence. Avoid SendUsingAccount when the
        # requested sender is already the default/only Outlook account.
        stage = "create Outlook mail item"
        mail = app.CreateItem(0)
        if use_default_send_path:
            log(f"Outlook send path: using default account {admin_mail_id}; SendUsingAccount not set (v5-compatible).")
        else:
            stage = "select non-default AdminMailID with SendUsingAccount"
            mail.SendUsingAccount = account
            log(f"Outlook send path: explicitly selected non-default account {admin_mail_id}.")

        stage = "assign To recipients"
        mail.To = "; ".join(recipients)
        stage = "assign CC recipients"
        mail.CC = "; ".join(cc_recipients)
        stage = "assign Subject"
        mail.Subject = subject
        stage = "assign Body"
        mail.Body = body
        stage = "call Outlook MailItem.Send()"
        mail.Send()
        log(f"Outlook MailItem.Send() returned successfully for {admin_mail_id}; To={'; '.join(recipients)}; CC={'; '.join(cc_recipients) or '(none)'}.")
        return True
    except Exception as exc:
        hresult = getattr(exc, "hresult", None)
        hresult_text = f" (HRESULT={hresult})" if hresult is not None else ""
        log(f"Email send failed at stage [{stage}] from {admin_mail_id}: {type(exc).__name__}: {exc}{hresult_text}", logging.ERROR)
        if stage == "call Outlook MailItem.Send()":
            log("Send() raised an exception. Check the AdminMailID Sent Items before retrying, in case Outlook submitted the message despite the COM error.", logging.ERROR)
        return False


def sender_smtp(message) -> str:
    """Resolve SMTP sender for normal SMTP and Exchange messages."""
    try:
        if str(getattr(message, "SenderEmailType", "")).upper() == "EX":
            sender = getattr(message, "Sender", None)
            if sender is not None:
                try:
                    exchange_user = sender.GetExchangeUser()
                    primary = getattr(exchange_user, "PrimarySmtpAddress", "") if exchange_user else ""
                    if primary:
                        return str(primary).strip().casefold()
                except Exception:
                    pass
            try:
                return str(message.PropertyAccessor.GetProperty(
                    "http://schemas.microsoft.com/mapi/proptag/0x39FE001F")).strip().casefold()
            except Exception:
                pass
        return str(getattr(message, "SenderEmailAddress", "") or "").strip().casefold()
    except Exception:
        return ""


def extract_status(body: str) -> str | None:
    """Accept an exact status line only from the newly typed reply portion."""
    lines = []
    for line in (body or "").replace("\r", "").split("\n"):
        stripped = line.strip()
        if re.match(r"^(From:|-----Original Message-----|On .+wrote:|_{5,})", stripped, re.I):
            break
        lines.append(stripped)
    for line in lines:
        match = re.match(r"^Status\s*:\s*(.*?)\s*$", line, re.I)
        if match:
            return STATUSES.get(match.group(1).strip().strip("<>[](){}.,;").casefold())
    return None


def is_reply_message(subject: str, message) -> bool:
    """Reject original reminders/forwarded messages; accept genuine reply subjects."""
    if not re.match(r"^\s*(RE|AW|答复|回复)\s*[:：]", subject or "", re.I):
        return False
    # Outlook received mail items are normally class 43. Reject sent items if exposed.
    try:
        if int(getattr(message, "Sent", False)) == 1:
            return False
    except Exception:
        pass
    return True


def poll_replies(rows: list[dict[str, Any]]) -> tuple[list[tuple], list[Any]]:
    """Read only genuine replies from each AdminMailID Inbox."""
    if not rows:
        return [], []
    app = outlook_app()
    rows_by_admin: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        admin = str(row.get("AdminMailID") or "").strip()
        if admin:
            rows_by_admin.setdefault(admin.casefold(), []).append(row)
    replies: list[tuple] = []
    messages_to_mark: list[Any] = []
    for admin_key, admin_rows in rows_by_admin.items():
        admin = str(admin_rows[0].get("AdminMailID")).strip()
        try:
            account = outlook_account(app, admin)
            store = account.DeliveryStore
            inbox = store.GetDefaultFolder(6)
            items = inbox.Items.Restrict("[Unread] = True")
            by_id = {str(row.get("ActivityID") or "").strip(): row for row in admin_rows}
            message = items.GetFirst()
            while message is not None:
                try:
                    subject = str(getattr(message, "Subject", "") or "")
                    body = str(getattr(message, "Body", "") or "")
                    # Critical safeguard: original reminder subject is not a reply.
                    if not is_reply_message(subject, message):
                        message = items.GetNext()
                        continue
                    match = re.search(r"ActivityID\s*:\s*([A-Za-z0-9_-]+)", subject + "\n" + body, re.I)
                    if not match:
                        message = items.GetNext()
                        continue
                    activity_id = match.group(1)
                    row = by_id.get(activity_id)
                    if row is None:
                        log(f"Reply in {admin} Inbox has unknown ActivityID {activity_id}; left unread.", logging.WARNING)
                        message = items.GetNext()
                        continue
                    sender = sender_smtp(message)
                    allowed = {email.casefold() for email in split_emails(row.get("AssignedTo"))}
                    if sender not in allowed:
                        log(f"Reply for ActivityID {activity_id} rejected: {sender} is not assigned; left unread.", logging.WARNING)
                        message = items.GetNext()
                        continue
                    status = extract_status(body)
                    if status:
                        replies.append((row, status, activity_id))
                        messages_to_mark.append(message)
                    else:
                        log(f"Reply for ActivityID {activity_id} has no valid Status line; left unread.", logging.WARNING)
                    message = items.GetNext()
                except Exception as exc:
                    log(f"An Inbox item in {admin} could not be read: {exc}", logging.WARNING)
                    try:
                        message = items.GetNext()
                    except Exception:
                        message = None
        except Exception as exc:
            log(f"Could not access Inbox for AdminMailID {admin}: {exc}", logging.ERROR)
    return replies, messages_to_mark

def mark_messages_read(messages: list[Any]) -> None:
    for message in messages:
        try:
            message.UnRead = False
            message.Save()
        except Exception as exc:
            log(f"Could not mark a processed reply as read: {exc}", logging.WARNING)


def send_overdue_toast(row: dict[str, Any], due: dt.datetime) -> bool:
    if ToastNotifier is None:
        return False
    try:
        ToastNotifier().show_toast(
            f"Task {row.get('ActivityID')} overdue",
            f"{row.get('Description', '')}\nDue: {due:%d-%m-%Y %H:%M}",
            duration=8, threaded=True,
        )
        return True
    except Exception as exc:
        log(f"Toast failed: {exc}", logging.WARNING)
        return False


def reminder_is_due(row: dict[str, Any], today: dt.date) -> bool:
    """Return whether a one-time catch-up or daily reminder is due today."""
    if str(row.get("CompletionStatus") or "").strip().casefold() == "completed":
        return False
    reminder_date = as_date(row.get("ReminderDate"))
    daily_start = as_date(row.get("DailyReminderStartDate"))
    reminded = str(row.get("RemindedStatus") or "").strip().casefold() == "reminded"
    one_time_due = reminder_date is not None and today >= reminder_date and not reminded
    daily_due = daily_start is not None and today >= daily_start
    return bool(one_time_due or daily_due)


def show_overdue_popup(items: list[tuple[dict[str, Any], dt.datetime]]) -> bool:
    """Show a short Tkinter popup as a fallback when win10toast is unavailable."""
    if not items or os.name != "nt":
        return False
    try:
        lines = [f"{row.get('ActivityID')}: {str(row.get('Description') or '')[:65]} (Due {due:%d-%m-%Y %H:%M})"
                 for row, due in items[:8]]
        if len(items) > 8:
            lines.append(f"...and {len(items) - 8} more overdue activities.")
        title = "CAMSTF - Overdue Activities"
        body = "The following activities are overdue:\n\n" + "\n".join(lines)
        popup_code = "\n".join([
            "import tkinter as tk, sys",
            "root = tk.Tk()",
            "root.title(sys.argv[1])",
            "root.attributes('-topmost', True)",
            "root.resizable(False, False)",
            "root.configure(bg='#FFF4E5')",
            "root.geometry('520x220')",
            "root.update_idletasks()",
            "x = max(0, root.winfo_screenwidth() - 540)",
            "y = max(0, root.winfo_screenheight() - 240)",
            "root.geometry(f'+{x}+{y}')",
            "tk.Label(root, text=sys.argv[1], bg='#FFF4E5', fg='#9A3412', font=('Segoe UI', 12, 'bold')).pack(anchor='w', padx=14, pady=(12, 6))",
            "tk.Message(root, text=sys.argv[2], width=480, bg='#FFF4E5', fg='#422006', font=('Segoe UI', 9)).pack(fill='both', expand=True, padx=14, pady=4)",
            "tk.Label(root, text='This notification closes automatically in 12 seconds.', bg='#FFF4E5', fg='#7C5A3A', font=('Segoe UI', 8)).pack(anchor='e', padx=14, pady=(0, 10))",
            "root.after(12000, root.destroy)",
            "root.mainloop()",
        ])
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        executable = str(pythonw if pythonw.exists() else Path(sys.executable))
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen([executable, "-c", popup_code, title, body], creationflags=flags, close_fds=True)
        return True
    except Exception as exc:
        log(f"Native overdue popup could not be launched: {exc}", logging.WARNING)
        return False


def process_run(show_overdue_popup_fallback: bool = True) -> list[tuple[dict[str, Any], dt.datetime]]:
    setup_log()
    log("===== Activity Manager v7.2 run started =====")
    rows = load_rows()
    today = dt.date.today()
    now = dt.datetime.now()
    changed = False

    # Process valid replies first so completed tasks are not reminded again.
    try:
        replies, messages_to_mark = poll_replies(rows)
    except Exception as exc:
        replies, messages_to_mark = [], []
        log(f"Inbox polling failed: {exc}", logging.ERROR)
    for row, status, activity_id in replies:
        if str(row.get("CompletionStatus") or "").strip().casefold() == "completed":
            log(f"ActivityID {activity_id}: already Completed; reply ignored.", logging.WARNING)
            continue
        row["CompletionStatus"] = status
        changed = True
        log(f"ActivityID {activity_id} updated to '{status}'.")

    # Catch up missed one-time ReminderDate events. A one-time reminder is sent
    # once (RemindedStatus=Reminded); daily reminders continue from their start date.
    for row in rows:
        if str(row.get("CompletionStatus") or "").strip().casefold() == "completed":
            continue
        activity_id = str(row.get("ActivityID") or "").strip()
        reminder_date = as_date(row.get("ReminderDate"))
        last_reminder = as_date(row.get("LastReminderDate"))
        reminded = str(row.get("RemindedStatus") or "").strip().casefold() == "reminded"
        one_time_due = reminder_date is not None and today >= reminder_date and not reminded
        daily_due = as_date(row.get("DailyReminderStartDate")) is not None and today >= as_date(row.get("DailyReminderStartDate"))
        if not reminder_is_due(row, today) or last_reminder == today:
            continue

        admin = str(row.get("AdminMailID") or "").strip()
        assigned = str(row.get("AssignedTo") or "").strip()
        manager = str(row.get("ManagerEmail") or "").strip()
        if not admin or not assigned:
            log(f"ActivityID {activity_id}: AdminMailID or AssignedTo is blank; reminder skipped.", logging.WARNING)
            continue
        due = as_due_datetime(row.get("DueDate"))
        due_text = due.strftime("%d-%m-%Y %H:%M") if due else "Not specified"
        description = str(row.get("Description") or "")
        subject = f"Reminder: {description} (ActivityID: {activity_id})"
        body = (
            "Hello,\n\nThis is a reminder regarding the following activity:\n\n"
            f"ActivityID: {activity_id}\nDescription: {description}\nDueDate: {due_text}\n\n"
            "Please reply to this email with one exact status line:\n"
            "Status: Completed\nStatus: Not Completed Yet\n"
            "Status: In Progress\nStatus: Delayed\n\nThank you."
        )
        if send_mail(admin, assigned, manager, subject, body):
            row["RemindedStatus"] = "Reminded"
            row["LastReminderDate"] = today
            changed = True
            reason = "missed ReminderDate catch-up" if one_time_due else "daily reminder"
            log(f"Reminder sent for ActivityID {activity_id} ({reason}); To={assigned}; CC={manager or '(none)'}; From={admin}.")

    overdue_rows = []
    popup_fallback_rows = []
    for row in rows:
        if str(row.get("CompletionStatus") or "").strip().casefold() == "completed":
            continue
        due = as_due_datetime(row.get("DueDate"))
        if due is None or now <= due:
            continue
        overdue_rows.append((row, due))
        if as_date(row.get("LastNotified")) == today:
            continue
        if ToastNotifier is None:
            log(f"win10toast is not installed; using Tkinter popup fallback for ActivityID {row.get('ActivityID')}.", logging.WARNING)
            popup_fallback_rows.append((row, due))
            continue
        if send_overdue_toast(row, due):
            row["LastNotified"] = today
            changed = True
        else:
            popup_fallback_rows.append((row, due))

    if show_overdue_popup_fallback and popup_fallback_rows and show_overdue_popup(popup_fallback_rows):
        for row, due in popup_fallback_rows:
            row["LastNotified"] = today
            changed = True
        log(f"Fallback overdue popup displayed for {len(popup_fallback_rows)} activity/activities.")

    if changed:
        save_rows(rows)
        log("Workbook updated successfully.")
    if messages_to_mark and replies:
        mark_messages_read(messages_to_mark)
    log(f"Overdue activities currently detected: {len(overdue_rows)}")
    log("===== Activity Manager v7.2 run completed =====")
    return overdue_rows


def format_digits_for_entry(variable, kind: str, entry):
    """Auto-insert DD-MM-YYYY or HH:MM separators while typing."""
    raw = variable.get()
    cursor = entry.index(tk.INSERT)
    digits_before = sum(ch.isdigit() for ch in raw[:cursor])
    digits = "".join(ch for ch in raw if ch.isdigit())
    limit = 8 if kind == "date" else 4
    digits = digits[:limit]
    if kind == "date":
        if len(digits) <= 2:
            formatted = digits
        elif len(digits) <= 4:
            formatted = digits[:2] + "-" + digits[2:]
        else:
            formatted = digits[:2] + "-" + digits[2:4] + "-" + digits[4:]
        # show separators immediately after completed day/month while typing
        if len(digits) == 2:
            formatted = digits + "-"
        elif len(digits) == 4:
            formatted = digits[:2] + "-" + digits[2:] + "-"
    else:
        formatted = digits if len(digits) <= 2 else digits[:2] + ":" + digits[2:]
        if len(digits) == 2:
            formatted = digits + ":"
    if formatted != raw:
        variable.set(formatted)
        pos = 0
        seen = 0
        while pos < len(formatted) and seen < digits_before:
            if formatted[pos].isdigit():
                seen += 1
            pos += 1
        entry.icursor(min(pos, len(formatted)))


def validate_date_text(value: str, label: str) -> dt.date | None:
    if not value.strip():
        return None
    if not re.fullmatch(r"\d{2}-\d{2}-\d{4}", value.strip()):
        raise ValueError(f"{label}: enter date as DD-MM-YYYY.")
    try:
        return dt.datetime.strptime(value.strip(), "%d-%m-%Y").date()
    except ValueError:
        raise ValueError(f"{label}: '{value}' is not a valid calendar date.")


class ActivityManagerGUI:
    NAVY = "#17365D"
    BLUE = "#2878B5"
    GREEN = "#27865B"
    RED = "#C74747"
    BG = "#E9EEF4"
    TEXT = "#203247"

    def __init__(self, root):
        self.root = root
        root.title("CAMSTF - Activity Manager")
        root.geometry("1420x860")
        root.minsize(1120, 720)
        root.configure(bg=self.BG)
        self.rows: list[dict[str, Any]] = []
        self.vars: dict[str, Any] = {}
        self.entries: dict[str, Any] = {}
        self.logo_images = []
        self.setup_styles()
        self.build_ui()
        self.refresh()

    def setup_styles(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Treeview", background="#FFFFFF", fieldbackground="#FFFFFF",
                        foreground=self.TEXT, rowheight=27, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", background=self.NAVY, foreground="#FFFFFF",
                        font=("Segoe UI", 9, "bold"), relief="flat")
        style.map("Treeview.Heading", background=[("active", self.BLUE)])
        style.configure("TEntry", padding=5)
        style.configure("TLabel", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 9))
        style.configure("TLabelframe", background=self.BG, foreground=self.NAVY)
        style.configure("TLabelframe.Label", background=self.BG, foreground=self.NAVY,
                        font=("Segoe UI", 10, "bold"))
        style.configure("TButton", padding=(10, 7), font=("Segoe UI", 9, "bold"))
        style.configure("Primary.TButton", background=self.BLUE, foreground="white")
        style.map("Primary.TButton", background=[("active", "#1E5F91")])
        style.configure("Success.TButton", background=self.GREEN, foreground="white")
        style.map("Success.TButton", background=[("active", "#1F6C49")])
        style.configure("Danger.TButton", background=self.RED, foreground="white")
        style.map("Danger.TButton", background=[("active", "#A93636")])

    def _load_logo(self, path: Path, size=(80, 80), watermark=False):
        if Image is None or not path.exists():
            return None
        try:
            image = Image.open(path).convert("RGBA")
            image.thumbnail(size, Image.Resampling.LANCZOS)
            canvas = Image.new("RGBA", size, (255, 255, 255, 0))
            x = (size[0] - image.width) // 2
            y = (size[1] - image.height) // 2
            canvas.alpha_composite(image, (x, y))
            if watermark:
                alpha = canvas.getchannel("A").point(lambda p: int(p * 0.10))
                canvas.putalpha(alpha)
            return ImageTk.PhotoImage(canvas)
        except Exception as exc:
            log(f"Could not load logo {path.name}: {exc}", logging.WARNING)
            return None

    def build_ui(self):
        header = tk.Frame(self.root, bg=self.NAVY, height=104)
        header.pack(fill="x")
        header.pack_propagate(False)
        left_logo = self._load_logo(TEAM_LOGO_PATH, (80, 80))
        right_logo = self._load_logo(COMPANY_LOGO_PATH, (80, 80))
        if left_logo:
            self.logo_images.append(left_logo)
            tk.Label(header, image=left_logo, bg="#FFFFFF", width=80, height=80).pack(side="left", padx=14, pady=12)
        else:
            tk.Label(header, text="TEAM\nLOGO", bg="#FFFFFF", fg=self.NAVY, width=10, height=4,
                     font=("Segoe UI", 8, "bold")).pack(side="left", padx=14, pady=12)
        title_frame = tk.Frame(header, bg=self.NAVY)
        title_frame.pack(side="left", expand=True, fill="both")
        tk.Label(title_frame, text="CAMSTF - Activity Manager", bg=self.NAVY, fg="white",
                 font=("Segoe UI", 23, "bold")).pack(expand=True)
        if right_logo:
            self.logo_images.append(right_logo)
            tk.Label(header, image=right_logo, bg="#FFFFFF", width=80, height=80).pack(side="right", padx=14, pady=12)
        else:
            tk.Label(header, text="COMPANY\nLOGO", bg="#FFFFFF", fg=self.NAVY, width=10, height=4,
                     font=("Segoe UI", 8, "bold")).pack(side="right", padx=14, pady=12)

        toolbar = tk.Frame(self.root, bg=self.BG, padx=10, pady=8)
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="Run reminders now", style="Success.TButton", command=self.run_now).pack(side="right", padx=4)
        ttk.Button(toolbar, text="Refresh", command=self.refresh).pack(side="right", padx=4)
        tk.Label(toolbar, text=f"Workbook and log are stored beside the application  |  {APP_DIR}",
                 bg=self.BG, fg="#52657A", font=("Segoe UI", 8)).pack(side="left")

        # Main activity table spans the window. The team watermark sits centered
        # in the middle strip beneath the table, so it remains visible and does
        # not obscure activity rows or form fields.
        main = tk.Frame(self.root, bg=self.BG, padx=10, pady=4)
        main.pack(fill="both", expand=True)
        main.rowconfigure(0, weight=1)
        main.columnconfigure(0, weight=1)
        table_frame = ttk.Frame(main)
        table_frame.grid(row=0, column=0, sticky="nsew")
        columns = ("ActivityID", "Description", "DueDate", "ReminderDate", "AssignedTo",
                   "RemindedStatus", "ManagerEmail", "DailyReminderStartDate", "AdminMailID", "CompletionStatus")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=11)
        widths = {"ActivityID": 78, "Description": 145, "DueDate": 140, "ReminderDate": 105,
                  "AssignedTo": 175, "RemindedStatus": 105, "ManagerEmail": 175,
                  "DailyReminderStartDate": 135, "AdminMailID": 175, "CompletionStatus": 120}
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=widths[col], minwidth=65, anchor="w")
        self.tree.tag_configure("overdue", foreground="#B42318", background="#FFF1F0")
        self.tree.tag_configure("completed", foreground="#64748B", background="#EEF2F6")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        watermark_panel = tk.Frame(self.root, bg=self.BG, height=132)
        watermark_panel.pack(fill="x", padx=10, pady=(0, 2))
        watermark_panel.pack_propagate(False)
        watermark = self._load_logo(TEAM_LOGO_PATH, (125, 125), watermark=True)
        if watermark:
            self.logo_images.append(watermark)
            tk.Label(watermark_panel, image=watermark, bg=self.BG).place(relx=0.5, rely=0.46, anchor="center")
        else:
            tk.Label(watermark_panel, text="TEAM LOGO WATERMARK", bg=self.BG, fg="#AAB6C4",
                     font=("Segoe UI", 13, "bold"), justify="center").place(relx=0.5, rely=0.46, anchor="center")

        form = ttk.LabelFrame(self.root, text="Activity details — manage records here; Excel is maintained automatically", padding=8)
        form.pack(fill="x", padx=10, pady=(4, 8))
        fields = [
            ("ActivityID", "Activity ID", None), ("Description", "Description", None),
            ("DueDate", "Due date (DD-MM-YYYY)", "date"), ("DueTime", "Due time (HH:MM, 24-hour)", "time"),
            ("ReminderDate", "Reminder date (DD-MM-YYYY)", "date"),
            ("DailyReminderStartDate", "Daily reminders start (DD-MM-YYYY)", "date"),
            ("AssignedTo", "Assigned engineer email(s), ; separated", None),
            ("ManagerEmail", "Manager email(s) for CC, ; separated", None),
            ("AdminMailID", "Admin Outlook account (sender)", None),
        ]
        for index, (key, label, fmt) in enumerate(fields):
            row, col = divmod(index, 3)
            frame = ttk.Frame(form)
            frame.grid(row=row, column=col, sticky="ew", padx=5, pady=4)
            ttk.Label(frame, text=label).pack(anchor="w")
            variable = tk.StringVar()
            self.vars[key] = variable
            entry = ttk.Entry(frame, textvariable=variable, width=42)
            entry.pack(fill="x")
            self.entries[key] = entry
            if fmt:
                entry.bind("<KeyRelease>", lambda event, v=variable, k=fmt, e=entry: format_digits_for_entry(v, k, e))
            form.columnconfigure(col, weight=1)

        controls = tk.Frame(self.root, bg=self.BG, padx=10, pady=4)
        controls.pack(fill="x")
        ttk.Button(controls, text="Add activity", style="Primary.TButton", command=self.add).pack(side="left", padx=4)
        ttk.Button(controls, text="Update selected", style="Success.TButton", command=self.update).pack(side="left", padx=4)
        ttk.Button(controls, text="Delete selected", style="Danger.TButton", command=self.delete).pack(side="left", padx=4)
        ttk.Button(controls, text="Clear form", command=self.clear).pack(side="left", padx=4)
        tk.Label(self.root, text="ReminderDate: one-time reminder (catch-up if a run is missed). Daily reminders repeat from DailyReminderStartDate until Completed. DueDate includes time.",
                 bg=self.BG, fg="#52657A", font=("Segoe UI", 8), padx=12, pady=5).pack(anchor="w")

    def refresh(self):
        try:
            self.rows = load_rows()
            for item in self.tree.get_children():
                self.tree.delete(item)
            now = dt.datetime.now()
            for row in self.rows:
                due = as_due_datetime(row.get("DueDate"))
                def date_text(value):
                    parsed = as_date(value)
                    return parsed.strftime("%d-%m-%Y") if parsed else ""
                values = [row.get("ActivityID", ""), row.get("Description", ""),
                          due.strftime("%d-%m-%Y %H:%M") if due else "", date_text(row.get("ReminderDate")),
                          row.get("AssignedTo", ""), row.get("RemindedStatus", ""), row.get("ManagerEmail", ""),
                          date_text(row.get("DailyReminderStartDate")), row.get("AdminMailID", ""), row.get("CompletionStatus", "")]
                tags = ()
                if str(row.get("CompletionStatus") or "").strip().casefold() == "completed":
                    tags = ("completed",)
                elif due and now > due:
                    tags = ("overdue",)
                self.tree.insert("", "end", iid=str(row["_row"]), values=values, tags=tags)
        except Exception as exc:
            messagebox.showerror("Workbook error", str(exc))

    def on_select(self, _event=None):
        selection = self.tree.selection()
        if not selection:
            return
        row_num = int(selection[0])
        row = next((item for item in self.rows if item["_row"] == row_num), None)
        if row is None:
            return
        for key, variable in self.vars.items():
            value = row.get(key)
            if key == "DueDate" and value:
                value = as_due_datetime(value).strftime("%d-%m-%Y")
            elif key == "DueTime" and row.get("DueDate"):
                value = as_due_datetime(row["DueDate"]).strftime("%H:%M")
            elif key in ("ReminderDate", "DailyReminderStartDate") and value:
                value = as_date(value).strftime("%d-%m-%Y")
            variable.set("" if value is None else str(value))

    def form_record(self, existing: dict[str, Any] | None = None) -> dict[str, Any]:
        record = {key: variable.get().strip() for key, variable in self.vars.items()}
        if not record["ActivityID"] or not record["Description"]:
            raise ValueError("Activity ID and Description are required.")
        due_day = validate_date_text(record["DueDate"], "Due date")
        due_time = record["DueTime"].strip()
        if due_day is None:
            raise ValueError("Enter Due date as DD-MM-YYYY.")
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", due_time):
            raise ValueError("Due time must be a valid 24-hour time HH:MM, e.g. 09:30 or 17:45.")
        record["DueDate"] = dt.datetime.combine(due_day, dt.datetime.strptime(due_time, "%H:%M").time())
        record.pop("DueTime", None)
        reminder = validate_date_text(record["ReminderDate"], "Reminder date")
        daily = validate_date_text(record["DailyReminderStartDate"], "Daily reminder start date")
        today = dt.date.today()
        old_reminder = as_date(existing.get("ReminderDate")) if existing else None
        old_daily = as_date(existing.get("DailyReminderStartDate")) if existing else None
        if reminder is not None and reminder < today and reminder != old_reminder:
            raise ValueError("ReminderDate cannot be earlier than today. Existing unchanged dates may be retained when editing.")
        if daily is not None and daily < today and daily != old_daily:
            raise ValueError("DailyReminderStartDate cannot be earlier than today. Existing unchanged dates may be retained when editing.")
        if reminder and daily and reminder >= daily:
            raise ValueError("ReminderDate must be earlier than DailyReminderStartDate.")
        record["ReminderDate"] = reminder
        record["DailyReminderStartDate"] = daily
        if not record["AssignedTo"]:
            raise ValueError("AssignedTo email is required.")
        if not record["AdminMailID"]:
            raise ValueError("AdminMailID is required.")
        return record

    def add(self):
        try:
            record = self.form_record()
            if any(str(row.get("ActivityID")).strip() == record["ActivityID"] for row in self.rows):
                raise ValueError("ActivityID already exists. Please enter a unique ID.")
            wb = openpyxl.load_workbook(WORKBOOK_PATH)
            ws = wb[SHEET]
            ws.append([record.get(header) for header in HEADERS])
            row_num = ws.max_row
            ws.cell(row_num, 3).number_format = "dd-mm-yyyy hh:mm"
            for col in (4, 8, 10, 11):
                ws.cell(row_num, col).number_format = "dd-mm-yyyy"
            ws.auto_filter.ref = f"A1:L{ws.max_row}"
            wb.save(WORKBOOK_PATH)
            self.clear()
            self.refresh()
            messagebox.showinfo("Activity added", "Activity was added successfully.")
        except Exception as exc:
            messagebox.showerror("Cannot add activity", str(exc))

    def update(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Select activity", "Select an activity first.")
            return
        row_num = int(selection[0])
        current = next((item for item in self.rows if item["_row"] == row_num), None)
        if current is None:
            messagebox.showerror("Cannot update activity", "Selected activity could not be found. Refresh and try again.")
            return
        if str(current.get("CompletionStatus") or "").strip().casefold() == "completed":
            messagebox.showwarning("Activity locked", "This activity is Completed and cannot be edited.")
            return
        try:
            record = self.form_record(existing=current)
            if any(str(row.get("ActivityID")).strip() == record["ActivityID"] and row["_row"] != row_num for row in self.rows):
                raise ValueError("ActivityID already exists. Please enter a unique ID.")
            wb = openpyxl.load_workbook(WORKBOOK_PATH)
            ws = wb[SHEET]
            existing = {header: ws.cell(row_num, col).value for col, header in enumerate(HEADERS, 1)}
            # Preserve completion state and notification history. If the one-time
            # ReminderDate itself changes, reset only its sent marker so the new
            # schedule can trigger once; LastReminderDate still prevents a same-day duplicate.
            for header in ("RemindedStatus", "LastReminderDate", "LastNotified", "CompletionStatus"):
                record[header] = existing.get(header)
            old_reminder_date = as_date(existing.get("ReminderDate"))
            if record.get("ReminderDate") != old_reminder_date:
                record["RemindedStatus"] = None
            for col, header in enumerate(HEADERS, 1):
                ws.cell(row_num, col).value = record.get(header)
            ws.cell(row_num, 3).number_format = "dd-mm-yyyy hh:mm"
            for col in (4, 8, 10, 11):
                ws.cell(row_num, col).number_format = "dd-mm-yyyy"
            wb.save(WORKBOOK_PATH)
            self.refresh()
            messagebox.showinfo("Activity updated", "Activity was updated successfully. Existing status and reminder history were preserved.")
        except Exception as exc:
            messagebox.showerror("Cannot update activity", str(exc))

    def delete(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Select activity", "Select an activity first.")
            return
        if not messagebox.askyesno("Confirm deletion", "Delete the selected activity permanently?"):
            return
        try:
            wb = openpyxl.load_workbook(WORKBOOK_PATH)
            wb[SHEET].delete_rows(int(selection[0]), 1)
            wb.save(WORKBOOK_PATH)
            self.clear()
            self.refresh()
        except Exception as exc:
            messagebox.showerror("Cannot delete activity", str(exc))

    def clear(self):
        for variable in self.vars.values():
            variable.set("")
        self.tree.selection_remove(self.tree.selection())

    def run_now(self):
        try:
            overdue = process_run(show_overdue_popup_fallback=False) or []
            self.refresh()
            if overdue:
                names = "\n".join(f"• {r.get('ActivityID')}: {r.get('Description')} (Due {due:%d-%m-%Y %H:%M})" for r, due in overdue[:12])
                if len(overdue) > 12:
                    names += f"\n...and {len(overdue)-12} more."
                messagebox.showwarning("Overdue activities", f"{len(overdue)} overdue activity/activities detected:\n\n{names}\n\nSee reminder_log.txt for notification details.")
            else:
                messagebox.showinfo("Activity Manager", "Reminder run completed. No overdue activities were detected. See reminder_log.txt for details.")
        except Exception as exc:
            messagebox.showerror("Reminder run failed", str(exc))


def main() -> None:
    parser = argparse.ArgumentParser(description="CAMSTF - Activity Manager v7.2")
    parser.add_argument("--run", action="store_true", help="Run the daily Outlook job and exit.")
    args = parser.parse_args()
    setup_log()
    ensure_schema()
    if args.run:
        process_run()
        return
    if tk is None:
        raise RuntimeError("Tkinter is unavailable. Install/use a standard Windows Python or Anaconda distribution with Tk support.")
    root = tk.Tk()
    ActivityManagerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
