CAMSTF - Activity Manager v7.2
================================

WHAT IS INCLUDED
- event_mng_v7.py: GUI and scheduled reminder program
- ActivityList.xlsx: Excel record workbook
- team_logo.png: replace this with your team logo (recommended source 500x500 px)
- company_logo.png: replace this with your company logo (recommended source 600x250 px)
- Start_Activity_Manager.bat: opens the GUI
- Run_Daily_Reminders.bat: runs the reminder job and exits
- Test_Outlook_Profile.py: checks Outlook account and Inbox access
- Test_Logic_v7_2.py: offline checks for date validation, reply filtering and reminder catch-up rules
- reminder_log.txt: created automatically beside the application

REQUIREMENTS
- Windows with Classic Outlook configured and signed in
- Python 3.12 (64-bit) / Anaconda environment
- openpyxl 3.1.5 or later
- pywin32 305 or later
- Pillow 10 or later for logo scaling/watermark (recommended; without it the GUI uses text placeholders)
- Optional win10toast for Windows toast notifications

FIRST RUN
1. Extract the complete folder to a writable location, e.g. C:\Apps\Activity_Manager_v7_2.
2. Back up any existing ActivityList.xlsx before replacing the template.
3. Replace team_logo.png and company_logo.png with your own PNG images. Keep the filenames unchanged.
4. Open Classic Outlook and sign in to the AdminMailID account.
5. Run Test_Outlook_Profile.py using the same Python environment.
6. Double-click Start_Activity_Manager.bat.

DATE/TIME ENTRY
- Due date: DD-MM-YYYY; separators are inserted automatically while typing.
- Due time: 24-hour HH:MM; colon is inserted automatically.
- Date fields must be real calendar dates (leap years are checked).
- ReminderDate and DailyReminderStartDate are date-only. If both are filled, ReminderDate must be earlier.
- On new tasks, reminder dates cannot be in the past. When editing, an unchanged existing past date can remain; a changed date cannot be set in the past.

EDITING RULE
- Only an activity with CompletionStatus=Completed is locked.
- Reminded, In Progress, Delayed and Not Completed Yet activities remain editable.
- Updating preserves system status and reminder history. Changing dates recalculates future eligibility.

REMINDER RULES
- One-time ReminderDate: sent when today is on or after ReminderDate if the one-time reminder has not already been sent. This catches up if the app missed the scheduled day.
- DailyReminderStartDate: sends daily from that date inclusive until CompletionStatus becomes Completed.
- At most one reminder per activity per calendar day.
- DueDate is the only time-sensitive field.

REPLY RULES
- Reply subject must begin with RE: (or common Outlook reply prefixes AW:/localized reply prefix).
- Reply must contain ActivityID and an exact Status line, e.g. Status: Completed.
- Sender must match one of AssignedTo addresses.
- Original reminder messages without a reply prefix are ignored, even when AdminMailID and AssignedTo are the same address.
- Valid reply is marked read only after the workbook has been saved.

OVERDUE INDICATION
- GUI highlights overdue activities in red.
- Clicking Run reminders now displays an overdue summary.
- Scheduled mode first tries win10toast. If it is unavailable or fails, v7.2 launches a short Tkinter popup using the same Python installation; it closes automatically after 12 seconds.
- For the scheduled popup to be visible, configure Task Scheduler to run only when the same Windows user is logged on. A task running in a non-interactive session cannot display a desktop popup.

TASK SCHEDULER
- Use Run_Daily_Reminders.bat as the program/script.
- Set the Start in directory to the application folder.
- Use the same Windows account and Outlook profile that owns AdminMailID.
- For Outlook COM, configure the task to run only when that user is logged on.
- Test the .bat manually before creating the scheduled task.

DATA SAFETY
- Close ActivityList.xlsx in Excel before running the application.
- Back up ActivityList.xlsx before upgrading.
- Keep the entire folder together; workbook and log paths are relative to this folder.
- Do not use on live operational activities until the tests in the supplied checklist pass.
