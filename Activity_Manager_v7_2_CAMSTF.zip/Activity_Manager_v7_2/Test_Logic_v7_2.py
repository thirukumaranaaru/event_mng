"""Offline logic checks for Activity Manager v7.2 (no Outlook send required)."""
import datetime as dt
import importlib.util
import unittest
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("activity_manager_v72", APP_DIR / "event_mng_v7.py")
am = importlib.util.module_from_spec(spec)
spec.loader.exec_module(am)

class ActivityManagerLogicTests(unittest.TestCase):
    today = dt.date(2026, 11, 19)

    def test_valid_calendar_date(self):
        self.assertEqual(am.validate_date_text("19-11-2026", "Date"), self.today)

    def test_leap_day_valid(self):
        self.assertEqual(am.validate_date_text("29-02-2024", "Date"), dt.date(2024, 2, 29))

    def test_invalid_calendar_dates_rejected(self):
        for value in ("31-02-2026", "19-13-2026", "29-02-2027", "1-11-2026"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                am.validate_date_text(value, "Date")

    def test_due_time_validation_pattern(self):
        import re
        pattern = r"(?:[01]\d|2[0-3]):[0-5]\d"
        for value in ("00:00", "09:30", "14:45", "23:59"):
            self.assertRegex(value, pattern)
        for value in ("24:00", "12:60", "7:30", "2560", "ab:cd"):
            self.assertNotRegex(value, pattern)

    def test_original_reminder_is_not_reply(self):
        msg = type("Message", (), {"Sent": False})()
        self.assertFalse(am.is_reply_message("Reminder: Test (ActivityID: 1)", msg))

    def test_genuine_reply_prefixes_are_accepted(self):
        msg = type("Message", (), {"Sent": False})()
        self.assertTrue(am.is_reply_message("RE: Reminder: Test (ActivityID: 1)", msg))
        self.assertTrue(am.is_reply_message("AW: Reminder: Test (ActivityID: 1)", msg))

    def test_forward_is_not_reply(self):
        msg = type("Message", (), {"Sent": False})()
        self.assertFalse(am.is_reply_message("FW: Reminder: Test", msg))

    def test_exact_status_values(self):
        self.assertEqual(am.extract_status("Status: Completed"), "Completed")
        self.assertEqual(am.extract_status("Status: Not Completed Yet"), "Not Completed Yet")
        self.assertEqual(am.extract_status("Status: In Progress"), "In Progress")
        self.assertEqual(am.extract_status("Status: Delayed"), "Delayed")
        self.assertIsNone(am.extract_status("Status: Done"))

    def test_quoted_original_status_is_ignored(self):
        body = "Hello,\nStatus: In Progress\n-----Original Message-----\nStatus: Completed"
        self.assertEqual(am.extract_status(body), "In Progress")

    def test_missed_one_time_reminder_catches_up(self):
        row = {"ReminderDate": dt.date(2026, 11, 18), "DailyReminderStartDate": dt.date(2026, 11, 22),
               "RemindedStatus": None, "CompletionStatus": None}
        self.assertTrue(am.reminder_is_due(row, self.today))

    def test_one_time_reminder_does_not_repeat_after_sent(self):
        row = {"ReminderDate": dt.date(2026, 11, 18), "DailyReminderStartDate": dt.date(2026, 11, 22),
               "RemindedStatus": "Reminded", "CompletionStatus": None}
        self.assertFalse(am.reminder_is_due(row, self.today))

    def test_daily_reminder_runs_after_start_date(self):
        row = {"ReminderDate": dt.date(2026, 11, 17), "DailyReminderStartDate": dt.date(2026, 11, 18),
               "RemindedStatus": "Reminded", "CompletionStatus": "In Progress"}
        self.assertTrue(am.reminder_is_due(row, self.today))

    def test_completed_task_never_reminded(self):
        row = {"ReminderDate": dt.date(2026, 11, 18), "DailyReminderStartDate": dt.date(2026, 11, 18),
               "RemindedStatus": None, "CompletionStatus": "Completed"}
        self.assertFalse(am.reminder_is_due(row, self.today))

if __name__ == "__main__":
    unittest.main(verbosity=2)
