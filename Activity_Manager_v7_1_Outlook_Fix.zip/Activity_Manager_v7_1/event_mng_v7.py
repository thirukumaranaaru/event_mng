#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Activity Manager v7.1. GUI mode: python event_mng_v7.py | Scheduled mode: --run

Outlook sending uses the v5-compatible default-account path when AdminMailID
is the default/only Outlook account; SendUsingAccount is used only for a
non-default account. Outlook COM failures are logged with the failing stage.
"""
from __future__ import annotations

import argparse
import datetime as dt
import logging
import re
import sys
from pathlib import Path
from typing import Any

import openpyxl
try:
    import win32com.client
except ImportError:
    win32com = None
try:
    from win10toast import ToastNotifier
except ImportError:
    ToastNotifier = None
try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:
    tk = None

APP_DIR = Path(__file__).resolve().parent
WORKBOOK_PATH = APP_DIR / "ActivityList.xlsx"
LOG_PATH = APP_DIR / "reminder_log.txt"
SHEET = "Activities"
HEADERS = [
    "ActivityID", "Description", "DueDate", "ReminderDate", "AssignedTo",
    "RemindedStatus", "ManagerEmail", "DailyReminderStartDate", "AdminMailID",
    "LastReminderDate", "LastNotified", "CompletionStatus",
]
STATUSES = {
    "completed": "Completed",
    "not completed yet": "Not Completed Yet",
    "in progress": "In Progress",
    "delayed": "Delayed",
}
DATE_ONLY = {"ReminderDate", "DailyReminderStartDate", "LastReminderDate", "LastNotified"}


def setup_log() -> None:
    logging.basicConfig(
        filename=LOG_PATH, level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s", encoding="utf-8",
    )


def log(message: str, level: int = logging.INFO) -> None:
    logging.log(level, message)
    print(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} - {message}")


def as_date(value: Any) -> dt.date | None:
    if value is None or str(value).strip() == "":
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    for fmt in ("%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y", "%Y/%m/%d"):
        try:
            return dt.datetime.strptime(str(value).strip(), fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Invalid date {value!r}; use DD-MM-YYYY.")


def as_due_datetime(value: Any) -> dt.datetime | None:
    if value is None or str(value).strip() == "":
        return None
    if isinstance(value, dt.datetime):
        return value
    if isinstance(value, dt.date):
        return dt.datetime.combine(value, dt.time.min)
    for fmt in ("%d-%m-%Y %H:%M", "%d-%m-%Y %H:%M:%S", "%d-%m-%Y",
                "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return dt.datetime.strptime(str(value).strip(), fmt)
        except ValueError:
            continue
    raise ValueError(f"Invalid DueDate {value!r}; use DD-MM-YYYY HH:MM.")


def split_emails(value: Any) -> list[str]:
    return [part.strip() for part in re.split(r"[;,]", str(value or "")) if part.strip()]


def style_sheet(ws) -> None:
    from openpyxl.styles import Font, PatternFill, Alignment
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:L{max(1, ws.max_row)}"
    for col, width in enumerate([12, 30, 22, 16, 32, 16, 32, 22, 32, 18, 18, 22], 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width
    # Format only existing data rows. Pre-creating hundreds of blank rows would
    # make Excel's append operation place new activities hundreds of rows down.
    for row in range(2, ws.max_row + 1):
        ws.cell(row, 3).number_format = "dd-mm-yyyy hh:mm"
        for col in (4, 8, 10, 11):
            ws.cell(row, col).number_format = "dd-mm-yyyy"


def ensure_schema() -> None:
    """Create the workbook if absent; migrate old headers only when necessary."""
    if not WORKBOOK_PATH.exists():
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = SHEET
        ws.append(HEADERS)
        style_sheet(ws)
        wb.save(WORKBOOK_PATH)
        return

    wb = openpyxl.load_workbook(WORKBOOK_PATH)
    ws = wb[SHEET] if SHEET in wb.sheetnames else wb.create_sheet(SHEET)
    # Older v6 templates preformatted hundreds of blank rows. Remove only empty
    # trailing rows so GUI Add appends immediately below the real records.
    original_max_row = ws.max_row
    while ws.max_row > 1 and all(ws.cell(ws.max_row, col).value is None for col in range(1, ws.max_column + 1)):
        ws.delete_rows(ws.max_row, 1)
    trimmed_blank_rows = ws.max_row != original_max_row
    current = [str(ws.cell(1, c).value or "").strip() for c in range(1, ws.max_column + 1)]
    if current[:len(HEADERS)] == HEADERS and all(not x for x in current[len(HEADERS):]):
        # Normal case: do not rewrite/rebuild the data rows on every run.
        if ws.max_column != len(HEADERS):
            for c in range(ws.max_column, len(HEADERS), -1):
                ws.delete_cols(c)
        if trimmed_blank_rows or ws.max_column != len(HEADERS):
            style_sheet(ws)
            wb.save(WORKBOOK_PATH)
        return

    rename = {"Status": "RemindedStatus"}
    normalized = [rename.get(name, name) for name in current]
    positions = {name: index + 1 for index, name in enumerate(normalized) if name}
    # Do not reinterpret old NotifyPeriodDays (a number) as a calendar date.
    for obsolete in ("ReminderDaysBefore", "NotifyPeriodDays"):
        positions.pop(obsolete, None)
    rows = []
    for row_num in range(2, ws.max_row + 1):
        values = [ws.cell(row_num, positions[h]).value if h in positions else None for h in HEADERS]
        if any(value is not None and str(value).strip() for value in values):
            rows.append(values)
    ws.delete_rows(1, ws.max_row)
    ws.append(HEADERS)
    for row in rows:
        ws.append(row)
    style_sheet(ws)
    wb.save(WORKBOOK_PATH)
    log("Workbook columns were migrated to the v7 format. Please review the records in the GUI.")


def load_rows() -> list[dict[str, Any]]:
    ensure_schema()
    wb = openpyxl.load_workbook(WORKBOOK_PATH)
    ws = wb[SHEET]
    rows: list[dict[str, Any]] = []
    for row_num in range(2, ws.max_row + 1):
        item = {header: ws.cell(row_num, col).value for col, header in enumerate(HEADERS, 1)}
        if any(value is not None and str(value).strip() for value in item.values()):
            item["_row"] = row_num
            rows.append(item)
    return rows


def save_rows(rows: list[dict[str, Any]]) -> None:
    wb = openpyxl.load_workbook(WORKBOOK_PATH)
    ws = wb[SHEET]
    for item in rows:
        row_num = item["_row"]
        for col, header in enumerate(HEADERS, 1):
            ws.cell(row_num, col).value = item.get(header)
        ws.cell(row_num, 3).number_format = "dd-mm-yyyy hh:mm"
        for col in (4, 8, 10, 11):
            ws.cell(row_num, col).number_format = "dd-mm-yyyy"
    wb.save(WORKBOOK_PATH)


def outlook_app():
    if win32com is None:
        raise RuntimeError("pywin32 is missing. Outlook integration requires Windows and Classic Outlook.")
    return win32com.client.Dispatch("Outlook.Application")


def outlook_account(app, admin_mail_id: str):
    wanted = admin_mail_id.strip().casefold()
    accounts = app.Session.Accounts
    for index in range(1, accounts.Count + 1):
        account = accounts.Item(index)
        smtp = str(getattr(account, "SmtpAddress", "") or "").strip().casefold()
        if smtp == wanted:
            return account
    raise RuntimeError(f"AdminMailID '{admin_mail_id}' is not configured as an account in this Outlook profile.")


def _account_is_default(app, account) -> bool | None:
    """Return True/False when Outlook exposes comparable delivery stores; else None."""
    try:
        default_store_id = str(app.Session.DefaultStore.StoreID)
        account_store_id = str(account.DeliveryStore.StoreID)
        return bool(default_store_id and account_store_id and default_store_id == account_store_id)
    except Exception:
        return None


def send_mail(admin_mail_id: str, to_value: str, cc_value: str, subject: str, body: str) -> bool:
    """Send mail using the v5-compatible default-account path where possible.

    If AdminMailID is the Outlook profile's default account (or the only
    configured account), do not set MailItem.SendUsingAccount. The earlier
    v5 implementation successfully used CreateItem -> To/Subject/Body -> Send.
    For a non-default account, SendUsingAccount remains necessary and is used
    explicitly. Each COM stage is logged so a failure can be diagnosed.
    """
    stage = "starting"
    try:
        stage = "connect to Outlook.Application"
        app = win32com.client.Dispatch("Outlook.Application")
        stage = "find AdminMailID account"
        account = outlook_account(app, admin_mail_id)
        wanted = admin_mail_id.strip().casefold()

        stage = "read Outlook account collection"
        accounts = app.Session.Accounts
        account_count = int(accounts.Count)
        is_default = _account_is_default(app, account)
        use_default_send_path = is_default is True or (is_default is None and account_count == 1)

        stage = "parse To recipients"
        recipients = split_emails(to_value)
        if not recipients:
            raise ValueError("AssignedTo is blank.")
        cc_recipients = split_emails(cc_value)

        # Match the working v5 send sequence. Avoid SendUsingAccount when the
        # requested sender is already the default/only Outlook account.
        stage = "create Outlook mail item"
        mail = app.CreateItem(0)
        if use_default_send_path:
            log(f"Outlook send path: using default account {admin_mail_id}; SendUsingAccount not set (v5-compatible).")
        else:
            stage = "select non-default AdminMailID with SendUsingAccount"
            mail.SendUsingAccount = account
            log(f"Outlook send path: explicitly selected non-default account {admin_mail_id}.")

        stage = "assign To recipients"
        mail.To = "; ".join(recipients)
        stage = "assign CC recipients"
        mail.CC = "; ".join(cc_recipients)
        stage = "assign Subject"
        mail.Subject = subject
        stage = "assign Body"
        mail.Body = body
        stage = "call Outlook MailItem.Send()"
        mail.Send()
        log(f"Outlook MailItem.Send() returned successfully for {admin_mail_id}; To={'; '.join(recipients)}; CC={'; '.join(cc_recipients) or '(none)'}.")
        return True
    except Exception as exc:
        hresult = getattr(exc, "hresult", None)
        hresult_text = f" (HRESULT={hresult})" if hresult is not None else ""
        log(f"Email send failed at stage [{stage}] from {admin_mail_id}: {type(exc).__name__}: {exc}{hresult_text}", logging.ERROR)
        if stage == "call Outlook MailItem.Send()":
            log("Send() raised an exception. Check the AdminMailID Sent Items before retrying, in case Outlook submitted the message despite the COM error.", logging.ERROR)
        return False


def sender_smtp(message) -> str:
    """Resolve SMTP sender for normal SMTP and Exchange messages."""
    try:
        if str(getattr(message, "SenderEmailType", "")).upper() == "EX":
            sender = getattr(message, "Sender", None)
            if sender is not None:
                try:
                    exchange_user = sender.GetExchangeUser()
                    primary = getattr(exchange_user, "PrimarySmtpAddress", "") if exchange_user else ""
                    if primary:
                        return str(primary).strip().casefold()
                except Exception:
                    pass
            try:
                return str(message.PropertyAccessor.GetProperty(
                    "http://schemas.microsoft.com/mapi/proptag/0x39FE001F")).strip().casefold()
            except Exception:
                pass
        return str(getattr(message, "SenderEmailAddress", "") or "").strip().casefold()
    except Exception:
        return ""


def extract_status(body: str) -> str | None:
    """Accept only a complete Status: value in the new reply portion."""
    lines = []
    for line in (body or "").replace("\r", "").split("\n"):
        stripped = line.strip()
        if re.match(r"^(From:|-----Original Message-----|On .+wrote:|_{5,})", stripped, re.I):
            break
        lines.append(stripped)
    for line in lines:
        match = re.match(r"^Status\s*:\s*(.*?)\s*$", line, re.I)
        if match:
            return STATUSES.get(match.group(1).strip().strip("<>[](){}.,;").casefold())
    return None


def poll_replies(rows: list[dict[str, Any]]) -> tuple[list[tuple], list[Any]]:
    """Read the Inbox belonging to each row's AdminMailID, not the default Inbox."""
    if not rows:
        return [], []
    app = outlook_app()
    rows_by_admin: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        admin = str(row.get("AdminMailID") or "").strip()
        if admin:
            rows_by_admin.setdefault(admin.casefold(), []).append(row)
    replies: list[tuple] = []
    messages_to_mark: list[Any] = []
    for admin_key, admin_rows in rows_by_admin.items():
        admin = str(admin_rows[0].get("AdminMailID")).strip()
        try:
            account = outlook_account(app, admin)
            store = account.DeliveryStore
            inbox = store.GetDefaultFolder(6)  # olFolderInbox for this account's delivery store
            items = inbox.Items.Restrict("[Unread] = True")
            by_id = {str(row.get("ActivityID") or "").strip(): row for row in admin_rows}
            message = items.GetFirst()
            while message is not None:
                try:
                    subject = str(getattr(message, "Subject", "") or "")
                    body = str(getattr(message, "Body", "") or "")
                    match = re.search(r"ActivityID\s*:\s*([A-Za-z0-9_-]+)", subject + "\n" + body, re.I)
                    if match:
                        activity_id = match.group(1)
                        row = by_id.get(activity_id)
                        if row is None:
                            log(f"Reply in {admin} Inbox has unknown ActivityID {activity_id}; left unread.", logging.WARNING)
                        else:
                            sender = sender_smtp(message)
                            allowed = {email.casefold() for email in split_emails(row.get("AssignedTo"))}
                            if sender not in allowed:
                                log(f"Reply for ActivityID {activity_id} rejected: {sender} is not assigned; left unread.", logging.WARNING)
                            else:
                                status = extract_status(body)
                                if status:
                                    replies.append((row, status, activity_id))
                                    messages_to_mark.append(message)
                    message = items.GetNext()
                except Exception as exc:
                    log(f"An Inbox item in {admin} could not be read: {exc}", logging.WARNING)
                    try:
                        message = items.GetNext()
                    except Exception:
                        message = None
        except Exception as exc:
            log(f"Could not access Inbox for AdminMailID {admin}: {exc}", logging.ERROR)
    return replies, messages_to_mark


def mark_messages_read(messages: list[Any]) -> None:
    for message in messages:
        try:
            message.UnRead = False
            message.Save()
        except Exception as exc:
            log(f"Could not mark a processed reply as read: {exc}", logging.WARNING)


def send_overdue_toast(row: dict[str, Any], due: dt.datetime) -> bool:
    if ToastNotifier is None:
        return False
    try:
        ToastNotifier().show_toast(
            f"Task {row.get('ActivityID')} overdue",
            f"{row.get('Description', '')}\nDue: {due:%d-%m-%Y %H:%M}",
            duration=8, threaded=True,
        )
        return True
    except Exception as exc:
        log(f"Toast failed: {exc}", logging.WARNING)
        return False


def process_run() -> None:
    setup_log()
    log("===== Activity Manager v7.1 run started =====")
    rows = load_rows()
    today = dt.date.today()
    now = dt.datetime.now()
    changed = False

    # First process replies so a task completed today is not reminded again today.
    try:
        replies, messages_to_mark = poll_replies(rows)
    except Exception as exc:
        replies, messages_to_mark = [], []
        log(f"Inbox polling failed: {exc}", logging.ERROR)
    for row, status, activity_id in replies:
        row["CompletionStatus"] = status
        changed = True
        log(f"ActivityID {activity_id} updated to '{status}'.")

    # Exact one-time ReminderDate, or daily from DailyReminderStartDate inclusive.
    for row in rows:
        if str(row.get("CompletionStatus") or "").strip().casefold() == "completed":
            continue
        activity_id = str(row.get("ActivityID") or "").strip()
        reminder_date = as_date(row.get("ReminderDate"))
        daily_start = as_date(row.get("DailyReminderStartDate"))
        last_reminder = as_date(row.get("LastReminderDate"))
        due_today = reminder_date == today
        daily_due = daily_start is not None and today >= daily_start
        if not (due_today or daily_due) or last_reminder == today:
            continue

        admin = str(row.get("AdminMailID") or "").strip()
        assigned = str(row.get("AssignedTo") or "").strip()
        manager = str(row.get("ManagerEmail") or "").strip()
        if not admin or not assigned:
            log(f"ActivityID {activity_id}: AdminMailID or AssignedTo is blank; reminder skipped.", logging.WARNING)
            continue
        due = as_due_datetime(row.get("DueDate"))
        due_text = due.strftime("%d-%m-%Y %H:%M") if due else "Not specified"
        description = str(row.get("Description") or "")
        subject = f"Reminder: {description} (ActivityID: {activity_id})"
        body = (
            "Hello,\n\nThis is a reminder regarding the following activity:\n\n"
            f"ActivityID: {activity_id}\nDescription: {description}\nDueDate: {due_text}\n\n"
            "Please reply with one exact status line:\n"
            "Status: Completed\nStatus: Not Completed Yet\n"
            "Status: In Progress\nStatus: Delayed\n\nThank you."
        )
        if send_mail(admin, assigned, manager, subject, body):
            row["RemindedStatus"] = "Reminded"
            row["LastReminderDate"] = today
            changed = True
            log(f"Reminder sent for ActivityID {activity_id}; To={assigned}; CC={manager or '(none)'}; From={admin}.")

    # DueDate is the only time-sensitive date. Other triggers compare calendar dates.
    for row in rows:
        if str(row.get("CompletionStatus") or "").strip().casefold() == "completed":
            continue
        due = as_due_datetime(row.get("DueDate"))
        if due is None or now <= due or as_date(row.get("LastNotified")) == today:
            continue
        if ToastNotifier is None:
            continue
        if send_overdue_toast(row, due):
            row["LastNotified"] = today
            changed = True

    # Save first; only then mark valid completion replies as read.
    if changed:
        save_rows(rows)
        log("Workbook updated successfully.")
    if messages_to_mark and replies:
        mark_messages_read(messages_to_mark)
    log("===== Activity Manager v7.1 run completed =====")


class ActivityManagerGUI:
    def __init__(self, root):
        self.root = root
        root.title("Activity Manager - Administrator Console")
        root.geometry("1320x760")
        self.rows: list[dict[str, Any]] = []
        self.vars: dict[str, Any] = {}
        self.build_ui()
        self.refresh()

    def build_ui(self):
        top = ttk.Frame(self.root, padding=8)
        top.pack(fill="x")
        ttk.Label(top, text=f"ACTIVITY MANAGER  |  Excel is the record store  |  {APP_DIR}").pack(side="left")
        ttk.Button(top, text="Refresh", command=self.refresh).pack(side="right", padx=3)
        ttk.Button(top, text="Run reminders now", command=self.run_now).pack(side="right", padx=3)

        columns = ("ActivityID", "Description", "DueDate", "ReminderDate", "AssignedTo",
                   "RemindedStatus", "ManagerEmail", "DailyReminderStartDate", "AdminMailID", "CompletionStatus")
        table_frame = ttk.Frame(self.root, padding=(8, 2))
        table_frame.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=13)
        widths = {"ActivityID": 80, "Description": 160, "DueDate": 145, "ReminderDate": 110,
                  "AssignedTo": 190, "RemindedStatus": 110, "ManagerEmail": 190,
                  "DailyReminderStartDate": 145, "AdminMailID": 190, "CompletionStatus": 130}
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=widths[col], minwidth=70, anchor="w")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        form = ttk.LabelFrame(self.root, text="Activity details — enter and edit here; no need to edit Excel", padding=8)
        form.pack(fill="x", padx=8, pady=6)
        fields = [
            ("ActivityID", "Activity ID"), ("Description", "Description"),
            ("DueDate", "Due date (DD-MM-YYYY)"), ("DueTime", "Due time (HH:MM, 24-hour)"),
            ("ReminderDate", "Reminder date (DD-MM-YYYY)"),
            ("DailyReminderStartDate", "Daily reminders start (DD-MM-YYYY)"),
            ("AssignedTo", "Assigned engineer email(s), ; separated"),
            ("ManagerEmail", "Manager email(s) for CC, ; separated"),
            ("AdminMailID", "Admin Outlook account (sender)"),
        ]
        for index, (key, label) in enumerate(fields):
            row, col = divmod(index, 3)
            frame = ttk.Frame(form)
            frame.grid(row=row, column=col, sticky="ew", padx=5, pady=4)
            ttk.Label(frame, text=label).pack(anchor="w")
            variable = tk.StringVar()
            self.vars[key] = variable
            ttk.Entry(frame, textvariable=variable, width=42).pack(fill="x")
            form.columnconfigure(col, weight=1)

        controls = ttk.Frame(self.root, padding=8)
        controls.pack(fill="x")
        for label, callback in (("Add activity", self.add), ("Update selected", self.update),
                                ("Delete selected", self.delete), ("Clear form", self.clear)):
            ttk.Button(controls, text=label, command=callback).pack(side="left", padx=4)
        ttk.Label(controls, text="Due date + time are required. Other dates are date-only.").pack(side="right")
        ttk.Label(self.root, text="ReminderDate sends on that date only. Daily reminders start on the selected date and repeat daily until Completed.", padding=6).pack(anchor="w")

    def refresh(self):
        try:
            self.rows = load_rows()
            for item in self.tree.get_children():
                self.tree.delete(item)
            for row in self.rows:
                due = as_due_datetime(row.get("DueDate"))
                def date_text(value):
                    parsed = as_date(value)
                    return parsed.strftime("%d-%m-%Y") if parsed else ""
                values = [
                    row.get("ActivityID", ""), row.get("Description", ""),
                    due.strftime("%d-%m-%Y %H:%M") if due else "", date_text(row.get("ReminderDate")),
                    row.get("AssignedTo", ""), row.get("RemindedStatus", ""), row.get("ManagerEmail", ""),
                    date_text(row.get("DailyReminderStartDate")), row.get("AdminMailID", ""),
                    row.get("CompletionStatus", ""),
                ]
                self.tree.insert("", "end", iid=str(row["_row"]), values=values)
        except Exception as exc:
            messagebox.showerror("Workbook error", str(exc))

    def on_select(self, _event=None):
        selection = self.tree.selection()
        if not selection:
            return
        row_num = int(selection[0])
        row = next((item for item in self.rows if item["_row"] == row_num), None)
        if row is None:
            return
        for key, variable in self.vars.items():
            value = row.get(key)
            if key == "DueDate" and value:
                value = as_due_datetime(value).strftime("%d-%m-%Y")
            elif key == "DueTime" and row.get("DueDate"):
                value = as_due_datetime(row["DueDate"]).strftime("%H:%M")
            elif key in ("ReminderDate", "DailyReminderStartDate") and value:
                value = as_date(value).strftime("%d-%m-%Y")
            variable.set("" if value is None else str(value))

    def form_record(self) -> dict[str, Any]:
        record = {key: variable.get().strip() for key, variable in self.vars.items()}
        if not record["ActivityID"] or not record["Description"]:
            raise ValueError("Activity ID and Description are required.")
        due_day = as_date(record["DueDate"])
        due_time = record["DueTime"]
        if due_day is None:
            raise ValueError("Enter Due date as DD-MM-YYYY.")
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", due_time):
            raise ValueError("Enter Due time in 24-hour HH:MM format, e.g. 09:30 or 17:45.")
        record["DueDate"] = dt.datetime.combine(due_day, dt.datetime.strptime(due_time, "%H:%M").time())
        record.pop("DueTime", None)
        record["ReminderDate"] = as_date(record["ReminderDate"])
        record["DailyReminderStartDate"] = as_date(record["DailyReminderStartDate"])
        if not record["AssignedTo"]:
            raise ValueError("AssignedTo email is required.")
        if not record["AdminMailID"]:
            raise ValueError("AdminMailID is required.")
        return record

    def add(self):
        try:
            record = self.form_record()
            if any(str(row.get("ActivityID")).strip() == record["ActivityID"] for row in self.rows):
                raise ValueError("ActivityID already exists. Please enter a unique ID.")
            wb = openpyxl.load_workbook(WORKBOOK_PATH)
            ws = wb[SHEET]
            ws.append([record.get(header) for header in HEADERS])
            row_num = ws.max_row
            ws.cell(row_num, 3).number_format = "dd-mm-yyyy hh:mm"
            for col in (4, 8, 10, 11):
                ws.cell(row_num, col).number_format = "dd-mm-yyyy"
            ws.auto_filter.ref = f"A1:L{ws.max_row}"
            wb.save(WORKBOOK_PATH)
            self.clear()
            self.refresh()
        except Exception as exc:
            messagebox.showerror("Cannot add activity", str(exc))

    def update(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Select activity", "Select an activity first.")
            return
        try:
            record = self.form_record()
            row_num = int(selection[0])
            if any(str(row.get("ActivityID")).strip() == record["ActivityID"] and row["_row"] != row_num for row in self.rows):
                raise ValueError("ActivityID already exists. Please enter a unique ID.")
            wb = openpyxl.load_workbook(WORKBOOK_PATH)
            ws = wb[SHEET]
            existing = {header: ws.cell(row_num, col).value for col, header in enumerate(HEADERS, 1)}
            for header in ("RemindedStatus", "LastReminderDate", "LastNotified", "CompletionStatus"):
                record[header] = existing.get(header)
            for col, header in enumerate(HEADERS, 1):
                ws.cell(row_num, col).value = record.get(header)
            ws.cell(row_num, 3).number_format = "dd-mm-yyyy hh:mm"
            for col in (4, 8, 10, 11):
                ws.cell(row_num, col).number_format = "dd-mm-yyyy"
            wb.save(WORKBOOK_PATH)
            self.refresh()
        except Exception as exc:
            messagebox.showerror("Cannot update activity", str(exc))

    def delete(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Select activity", "Select an activity first.")
            return
        if not messagebox.askyesno("Confirm deletion", "Delete the selected activity permanently?"):
            return
        try:
            wb = openpyxl.load_workbook(WORKBOOK_PATH)
            wb[SHEET].delete_rows(int(selection[0]), 1)
            wb.save(WORKBOOK_PATH)
            self.clear()
            self.refresh()
        except Exception as exc:
            messagebox.showerror("Cannot delete activity", str(exc))

    def clear(self):
        for variable in self.vars.values():
            variable.set("")

    def run_now(self):
        try:
            process_run()
            messagebox.showinfo("Activity Manager", "Reminder run completed. See reminder_log.txt for details.")
            self.refresh()
        except Exception as exc:
            messagebox.showerror("Reminder run failed", str(exc))


def main() -> None:
    parser = argparse.ArgumentParser(description="Activity Manager")
    parser.add_argument("--run", action="store_true", help="Run the daily Outlook job and exit.")
    args = parser.parse_args()
    setup_log()
    ensure_schema()
    if args.run:
        process_run()
        return
    if tk is None:
        raise RuntimeError("Tkinter is unavailable. Install/use a standard Windows Python or Anaconda distribution with Tk support.")
    root = tk.Tk()
    ActivityManagerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
