#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Activity Manager v6. Run GUI normally; schedule with: python event_mng_v6.py --run"""

from __future__ import annotations
import argparse, datetime as dt, logging, re, sys
from pathlib import Path

import openpyxl
try:
    import win32com.client
except ImportError:
    win32com = None
try:
    from win10toast import ToastNotifier
except ImportError:
    ToastNotifier = None
try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:
    tk = None

# All files live beside this script; no machine-specific paths.
APP_DIR = Path(__file__).resolve().parent
WORKBOOK_PATH = APP_DIR / "ActivityList.xlsx"
LOG_PATH = APP_DIR / "reminder_log.txt"
SHEET = "Activities"
HEADERS = ["ActivityID","Description","DueDate","ReminderDate","AssignedTo",
           "RemindedStatus","ManagerEmail","DailyReminderStartDate","AdminMailID",
           "LastReminderDate","LastNotified","CompletionStatus"]
STATUSES = {"completed":"Completed", "not completed yet":"Not Completed Yet",
            "in progress":"In Progress", "delayed":"Delayed"}
DATE_ONLY = {"ReminderDate","DailyReminderStartDate","LastReminderDate","LastNotified"}

def setup_log():
    logging.basicConfig(filename=LOG_PATH, level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s", encoding="utf-8")

def log(msg, level=logging.INFO):
    logging.log(level, msg)
    print(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} - {msg}")

def as_date(v):
    if v is None or str(v).strip() == "": return None
    if isinstance(v, dt.datetime): return v.date()
    if isinstance(v, dt.date): return v
    for fmt in ("%d-%m-%Y","%Y-%m-%d","%d/%m/%Y","%Y/%m/%d"):
        try: return dt.datetime.strptime(str(v).strip(),fmt).date()
        except ValueError: pass
    raise ValueError(f"Invalid date {v!r}; use DD-MM-YYYY.")

def as_due_datetime(v):
    if v is None or str(v).strip() == "": return None
    if isinstance(v, dt.datetime): return v
    if isinstance(v, dt.date): return dt.datetime.combine(v,dt.time.min)
    s=str(v).strip()
    for fmt in ("%d-%m-%Y %H:%M","%d-%m-%Y %H:%M:%S","%d-%m-%Y",
                "%Y-%m-%d %H:%M","%Y-%m-%d %H:%M:%S"):
        try: return dt.datetime.strptime(s,fmt)
        except ValueError: pass
    raise ValueError(f"Invalid DueDate {v!r}; use DD-MM-YYYY or DD-MM-YYYY HH:MM.")

def emails(v):
    return [x.strip() for x in re.split(r"[;,]",str(v or "")) if x.strip()]

def ensure_schema():
    if not WORKBOOK_PATH.exists():
        wb=openpyxl.Workbook(); ws=wb.active; ws.title=SHEET; ws.append(HEADERS)
        wb.save(WORKBOOK_PATH); return
    wb=openpyxl.load_workbook(WORKBOOK_PATH)
    ws=wb[SHEET] if SHEET in wb.sheetnames else wb.create_sheet(SHEET)
    old=[str(ws.cell(1,c).value or "").strip() for c in range(1,ws.max_column+1)]
    rename={"Status":"RemindedStatus"}
    old=[rename.get(x,x) for x in old]
    for i,x in enumerate(old,1): ws.cell(1,i).value=x
    # Old ReminderDaysBefore is intentionally removed: ReminderDate replaces it.
    for obsolete in ("ReminderDaysBefore", "NotifyPeriodDays"):
        if obsolete in old:
            j=old.index(obsolete)+1
            ws.delete_cols(j)
            old.pop(j-1)
    pos={str(ws.cell(1,c).value):c for c in range(1,ws.max_column+1)}
    data=[]
    for r in range(2,ws.max_row+1):
        data.append([ws.cell(r,pos[h]).value if h in pos else None for h in HEADERS])
    ws.delete_rows(1,ws.max_row); ws.append(HEADERS)
    for row in data: ws.append(row)
    for c in ws[1]:
        c.font=openpyxl.styles.Font(bold=True,color="FFFFFF")
        c.fill=openpyxl.styles.PatternFill("solid",fgColor="1F4E78")
        c.alignment=openpyxl.styles.Alignment(horizontal="center",wrap_text=True)
    ws.freeze_panes="A2"; ws.auto_filter.ref=f"A1:L{max(1,ws.max_row)}"
    for i,w in enumerate([12,30,22,16,32,16,32,22,32,18,18,22],1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width=w
    for r in range(2,max(502,ws.max_row+1)):
        ws.cell(r,3).number_format="dd-mm-yyyy hh:mm"
        for c in (4,8,10,11): ws.cell(r,c).number_format="dd-mm-yyyy"
    wb.save(WORKBOOK_PATH)

def load_rows():
    ensure_schema(); wb=openpyxl.load_workbook(WORKBOOK_PATH); ws=wb[SHEET]
    headers=[ws.cell(1,c).value for c in range(1,ws.max_column+1)]
    rows=[]
    for r in range(2,ws.max_row+1):
        d={h:ws.cell(r,c).value for c,h in enumerate(headers,1)}
        if any(v is not None and str(v).strip() for v in d.values()):
            d["_row"]=r; rows.append(d)
    return rows

def save_rows(rows):
    wb=openpyxl.load_workbook(WORKBOOK_PATH); ws=wb[SHEET]
    for item in rows:
        r=item["_row"]
        for c,h in enumerate(HEADERS,1):
            ws.cell(r,c).value=item.get(h)
        ws.cell(r,3).number_format="dd-mm-yyyy hh:mm"
        for c in (4,8,10,11): ws.cell(r,c).number_format="dd-mm-yyyy"
    wb.save(WORKBOOK_PATH)

def outlook():
    if win32com is None: raise RuntimeError("pywin32 missing; Outlook automation needs Windows and Classic Outlook.")
    return win32com.client.Dispatch("Outlook.Application")

def account_for(app, admin):
    accounts=app.Session.Accounts
    for i in range(1,accounts.Count+1):
        a=accounts.Item(i)
        if str(getattr(a,"SmtpAddress","")).strip().lower()==admin.strip().lower(): return a
    raise RuntimeError(f"AdminMailID {admin!r} is not configured in this Outlook profile.")

def send_mail(admin,to,cc,subject,body):
    try:
        app=outlook(); mail=app.CreateItem(0); mail.SendUsingAccount=account_for(app,admin)
        mail.To="; ".join(emails(to)); mail.CC="; ".join(emails(cc))
        if not mail.To: raise ValueError("AssignedTo is empty.")
        mail.Subject=subject; mail.Body=body; mail.Send(); return True
    except Exception as e:
        log(f"Email send failed from {admin}: {e}",logging.ERROR); return False

def sender_smtp(msg):
    try:
        if str(msg.SenderEmailType).upper()=="EX":
            return str(msg.PropertyAccessor.GetProperty(
                "http://schemas.microsoft.com/mapi/proptag/0x39FE001E")).lower()
        return str(msg.SenderEmailAddress or "").lower()
    except Exception: return str(getattr(msg,"SenderEmailAddress","") or "").lower()

def newest_status(body):
    lines=[]
    for line in (body or "").replace("\r","").split("\n"):
        s=line.strip()
        if re.match(r"^(From:|-----Original Message-----|On .+wrote:|_{5,})",s,re.I): break
        lines.append(s)
    for line in lines:
        m=re.match(r"^Status\s*:\s*(.*?)\s*$",line,re.I)
        if m: return STATUSES.get(m.group(1).strip().strip("<>[](){}.,;").casefold())
    return None

def poll_replies(rows):
    app=outlook(); inbox=app.Session.GetDefaultFolder(6)
    items=inbox.Items.Restrict("[Unread] = True")
    byid={str(r.get("ActivityID") or "").strip():r for r in rows}
    replies=[]; to_mark=[]
    for msg in list(items):
        try:
            subj=str(getattr(msg,"Subject","") or ""); body=str(getattr(msg,"Body","") or "")
            m=re.search(r"ActivityID\s*:\s*([A-Za-z0-9_-]+)",subj+"\n"+body,re.I)
            if not m: continue
            aid=m.group(1); row=byid.get(aid)
            if row is None:
                log(f"Unknown ActivityID {aid}; reply left unread.",logging.WARNING); continue
            sender=sender_smtp(msg)
            permitted={x.lower() for x in emails(row.get("AssignedTo"))}
            if sender not in permitted:
                log(f"Rejected reply for {aid} from unassigned sender {sender}.",logging.WARNING); continue
            status=newest_status(body)
            if not status: continue
            replies.append((row,status,aid)); to_mark.append(msg)
        except Exception as e: log(f"Inbox item skipped: {e}",logging.WARNING)
    return replies,to_mark

def process_run():
    setup_log(); log("=== Activity Manager run started ===")
    rows=load_rows(); today=dt.date.today(); now=dt.datetime.now()
    replies=[]; to_mark=[]
    try: replies,to_mark=poll_replies(rows)
    except Exception as e: log(f"Could not process Inbox: {e}",logging.ERROR)
    changed=False
    for row,status,aid in replies:
        row["CompletionStatus"]=status; changed=True
        log(f"ActivityID {aid} updated to {status}.")
    # ReminderDate is a one-day trigger. DailyReminderStartDate triggers each day
    # from that date onwards. If both match, still send only one email per day.
    for row in rows:
        if str(row.get("CompletionStatus") or "").strip().casefold()=="completed": continue
        aid=str(row.get("ActivityID") or "").strip()
        rdate=as_date(row.get("ReminderDate"))
        daily_start=as_date(row.get("DailyReminderStartDate"))
        last=as_date(row.get("LastReminderDate"))
        should_send=(rdate==today) or (daily_start is not None and today>=daily_start)
        if not should_send or last==today: continue
        admin=str(row.get("AdminMailID") or "").strip()
        assignee=str(row.get("AssignedTo") or "").strip()
        manager=str(row.get("ManagerEmail") or "").strip()
        if not admin or not assignee:
            log(f"ActivityID {aid}: AdminMailID or AssignedTo missing; no email sent.",logging.WARNING); continue
        due=as_due_datetime(row.get("DueDate"))
        due_text=due.strftime("%d-%m-%Y %H:%M") if due else "Not entered"
        desc=str(row.get("Description") or "")
        subject=f"Reminder: {desc} (ActivityID: {aid})"
        body=("Hello,\n\nThis is a reminder for the following activity:\n\n"
              f"ActivityID: {aid}\nDescription: {desc}\nDueDate: {due_text}\n\n"
              "Please reply with one exact status line:\n"
              "Status: Completed\nStatus: Not Completed Yet\n"
              "Status: In Progress\nStatus: Delayed\n\nThank you.")
        if send_mail(admin,assignee,manager,subject,body):
            row["RemindedStatus"]="Reminded"; row["LastReminderDate"]=today
            changed=True; log(f"Reminder sent for ActivityID {aid}; To={assignee}; CC={manager or '(none)'}")
    # DueDate alone is time-sensitive for overdue toast.
    for row in rows:
        if str(row.get("CompletionStatus") or "").strip().casefold()=="completed": continue
        due=as_due_datetime(row.get("DueDate"))
        if not due or now<=due or as_date(row.get("LastNotified"))==today: continue
        if ToastNotifier is None:
            log("win10toast missing; toast skipped."); continue
        try:
            ToastNotifier().show_toast(f"Task {row.get('ActivityID')} overdue",
                f"{row.get('Description','')}\\nDue: {due:%d-%m-%Y %H:%M}",duration=8,threaded=True)
            row["LastNotified"]=today; changed=True
        except Exception as e: log(f"Toast failed: {e}",logging.WARNING)
    if changed:
        save_rows(rows); log("Workbook saved.")
        for msg in to_mark:
            try: msg.UnRead=False; msg.Save()
            except Exception as e: log(f"Could not mark processed reply read: {e}",logging.WARNING)
    log("=== Activity Manager run completed ===")

class GUI:
    def __init__(self,root):
        self.root=root; root.title("Activity Manager v6"); root.geometry("1280x700")
        self.rows=[]; self.vars={}; self.build(); self.refresh()
    def build(self):
        bar=ttk.Frame(self.root,padding=8); bar.pack(fill="x")
        ttk.Label(bar,text=f"Files are stored beside the application: {APP_DIR}").pack(side="left")
        ttk.Button(bar,text="Refresh",command=self.refresh).pack(side="right",padx=3)
        ttk.Button(bar,text="Run reminders now",command=self.run_now).pack(side="right",padx=3)
        cols=("ActivityID","Description","DueDate","ReminderDate","AssignedTo","RemindedStatus","ManagerEmail","DailyReminderStartDate","AdminMailID","CompletionStatus")
        self.tree=ttk.Treeview(self.root,columns=cols,show="headings",height=14)
        for c in cols: self.tree.heading(c,text=c); self.tree.column(c,width=125 if c!="Description" else 170,anchor="w")
        self.tree.pack(fill="both",expand=True,padx=8,pady=5); self.tree.bind("<<TreeviewSelect>>",self.select)
        box=ttk.LabelFrame(self.root,text="Activity details",padding=8); box.pack(fill="x",padx=8,pady=5)
        fields=[("ActivityID","ActivityID"),("Description","Description"),
          ("DueDate","DueDate (DD-MM-YYYY)"),
          ("DueTime","DueTime (HH:MM; required)"),
          ("ReminderDate","ReminderDate (DD-MM-YYYY)"),("AssignedTo","AssignedTo (; separated)"),
          ("ManagerEmail","ManagerEmail (CC)"),
          ("DailyReminderStartDate","DailyReminderStartDate (DD-MM-YYYY)"),
          ("AdminMailID","AdminMailID (Outlook sender)")]
        for i,(key,label) in enumerate(fields):
            r,c=divmod(i,4); f=ttk.Frame(box); f.grid(row=r,column=c,sticky="ew",padx=4,pady=3)
            ttk.Label(f,text=label).pack(anchor="w"); v=tk.StringVar(); self.vars[key]=v
            ttk.Entry(f,textvariable=v,width=34).pack(fill="x"); box.columnconfigure(c,weight=1)
        buttons=ttk.Frame(self.root,padding=8); buttons.pack(fill="x")
        for label,cmd in [("Add activity",self.add),("Update selected",self.update),
                          ("Delete selected",self.delete),("Clear form",self.clear)]:
            ttk.Button(buttons,text=label,command=cmd).pack(side="left",padx=3)
        ttk.Label(buttons,text="DueDate requires date + time; all other dates are date-only (DD-MM-YYYY).").pack(side="right")
    def refresh(self):
        try:
            self.rows=load_rows()
            for x in self.tree.get_children(): self.tree.delete(x)
            for r in self.rows:
                due=as_due_datetime(r.get("DueDate"))
                def fmt(v): return as_date(v).strftime("%d-%m-%Y") if v else ""
                vals=[r.get("ActivityID",""),r.get("Description",""),
                    due.strftime("%d-%m-%Y %H:%M") if due else "",fmt(r.get("ReminderDate")),
                    r.get("AssignedTo",""),r.get("RemindedStatus",""),r.get("ManagerEmail",""),
                    fmt(r.get("DailyReminderStartDate")),r.get("AdminMailID",""),r.get("CompletionStatus","")]
                self.tree.insert("","end",iid=str(r["_row"]),values=vals)
        except Exception as e: messagebox.showerror("Workbook error",str(e))
    def select(self,_=None):
        sel=self.tree.selection()
        if not sel:return
        row=next((x for x in self.rows if x["_row"]==int(sel[0])),None)
        if not row:return
        for k,v in self.vars.items():
            x=row.get(k)
            if k=="DueDate" and x: x=as_due_datetime(x).strftime("%d-%m-%Y")
            elif k=="DueTime" and row.get("DueDate"): x=as_due_datetime(row.get("DueDate")).strftime("%H:%M")
            elif k in ("ReminderDate","DailyReminderStartDate") and x: x=as_date(x).strftime("%d-%m-%Y")
            v.set("" if x is None else str(x))
    def record(self):
        d={k:v.get().strip() for k,v in self.vars.items()}
        if not d["ActivityID"] or not d["Description"]: raise ValueError("ActivityID and Description are required.")
        due_day=as_date(d["DueDate"])
        due_time=d.get("DueTime","").strip()
        if not due_day: raise ValueError("DueDate is required (DD-MM-YYYY).")
        if not re.fullmatch(r"(?:[01]\\d|2[0-3]):[0-5]\\d", due_time):
            raise ValueError("DueTime is required in 24-hour HH:MM format, e.g. 09:30 or 17:45.")
        d["DueDate"]=dt.datetime.combine(due_day,dt.datetime.strptime(due_time,"%H:%M").time())
        d.pop("DueTime",None)
        d["ReminderDate"]=as_date(d["ReminderDate"])
        d["DailyReminderStartDate"]=as_date(d["DailyReminderStartDate"])
        if not d["DueDate"]: raise ValueError("Enter DueDate as DD-MM-YYYY or DD-MM-YYYY HH:MM.")
        if not d["AssignedTo"] or not d["AdminMailID"]: raise ValueError("AssignedTo and AdminMailID are required.")
        return d
    def add(self):
        try:
            d=self.record()
            if any(str(x.get("ActivityID"))==d["ActivityID"] for x in self.rows): raise ValueError("ActivityID already exists.")
            wb=openpyxl.load_workbook(WORKBOOK_PATH); ws=wb[SHEET]
            ws.append([d.get(h) for h in HEADERS]); r=ws.max_row
            ws.cell(r,3).number_format="dd-mm-yyyy hh:mm"
            for c in (4,8,10,11): ws.cell(r,c).number_format="dd-mm-yyyy"
            wb.save(WORKBOOK_PATH); self.clear(); self.refresh()
        except Exception as e: messagebox.showerror("Add failed",str(e))
    def update(self):
        sel=self.tree.selection()
        if not sel: messagebox.showwarning("Select","Select an activity."); return
        try:
            d=self.record(); r=int(sel[0])
            if any(str(x.get("ActivityID"))==d["ActivityID"] and x["_row"]!=r for x in self.rows): raise ValueError("ActivityID already exists.")
            wb=openpyxl.load_workbook(WORKBOOK_PATH); ws=wb[SHEET]
            # Preserve fields maintained automatically by the reminder engine.
            existing={h:ws.cell(r,c).value for c,h in enumerate(HEADERS,1)}
            for h in ("RemindedStatus","LastReminderDate","LastNotified","CompletionStatus"):
                d[h]=existing.get(h)
            for c,h in enumerate(HEADERS,1): ws.cell(r,c).value=d.get(h)
            ws.cell(r,3).number_format="dd-mm-yyyy hh:mm"
            for c in (4,8,10,11): ws.cell(r,c).number_format="dd-mm-yyyy"
            wb.save(WORKBOOK_PATH); self.refresh()
        except Exception as e: messagebox.showerror("Update failed",str(e))
    def delete(self):
        sel=self.tree.selection()
        if not sel:return
        if not messagebox.askyesno("Confirm","Delete selected activity?"):return
        wb=openpyxl.load_workbook(WORKBOOK_PATH); wb[SHEET].delete_rows(int(sel[0]),1); wb.save(WORKBOOK_PATH); self.clear(); self.refresh()
    def clear(self):
        for v in self.vars.values():v.set("")
    def run_now(self):
        try: process_run(); messagebox.showinfo("Run","Reminder run finished. See reminder_log.txt."); self.refresh()
        except Exception as e: messagebox.showerror("Run failed",str(e))

def main():
    p=argparse.ArgumentParser(); p.add_argument("--run",action="store_true"); args=p.parse_args()
    setup_log(); ensure_schema()
    if args.run: process_run(); return
    if tk is None: raise RuntimeError("Tkinter is unavailable.")
    root=tk.Tk(); GUI(root); root.mainloop()

if __name__=="__main__": main()
