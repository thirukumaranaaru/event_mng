@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_CMD="
if defined ACTIVITY_MANAGER_PYTHON set "PYTHON_CMD="%ACTIVITY_MANAGER_PYTHON%""
if not defined PYTHON_CMD if defined CONDA_PREFIX if exist "%CONDA_PREFIX%\python.exe" set "PYTHON_CMD="%CONDA_PREFIX%\python.exe""
if not defined PYTHON_CMD if exist "%USERPROFILE%\anaconda3\python.exe" set "PYTHON_CMD="%USERPROFILE%\anaconda3\python.exe""
if not defined PYTHON_CMD if exist "%USERPROFILE%\miniconda3\python.exe" set "PYTHON_CMD="%USERPROFILE%\miniconda3\python.exe""
if not defined PYTHON_CMD if exist "%LOCALAPPDATA%\anaconda3\python.exe" set "PYTHON_CMD="%LOCALAPPDATA%\anaconda3\python.exe""
if not defined PYTHON_CMD if exist "%LOCALAPPDATA%\miniconda3\python.exe" set "PYTHON_CMD="%LOCALAPPDATA%\miniconda3\python.exe""
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  where py >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=py -3.12"
)
if not defined PYTHON_CMD (
  echo Python was not found. Use Anaconda Prompt or set ACTIVITY_MANAGER_PYTHON.
  pause
  exit /b 1
)
%PYTHON_CMD% -c "import sys, openpyxl, win32com.client, tkinter; assert sys.version_info[:2] == (3,12), 'Use Python 3.12'; print('Python:',sys.version); print('openpyxl:',openpyxl.__version__); print('pywin32/Outlook COM: import OK'); print('tkinter: import OK')"
if errorlevel 1 (
  echo.
  echo One or more required components are missing. See README_Activity_Manager_v7.txt.
  pause
  exit /b 1
)
echo.
echo Basic dependency check passed. Outlook account and delivery still need a live test.
pause
