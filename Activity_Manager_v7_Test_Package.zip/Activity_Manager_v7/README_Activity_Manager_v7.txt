ACTIVITY MANAGER v7 - TRANSFER / TEST GUIDE
===========================================

1. FILES
--------
Keep all files in this folder together:
  event_mng_v7.py
  ActivityList.xlsx
  Start_Activity_Manager.bat
  Run_Daily_Reminders.bat
  Check_Installation.bat
  requirements.txt

The application creates reminder_log.txt in this same folder automatically.
The program does not use a fixed C:\ path. You may place this folder on another drive.
Do not rename ActivityList.xlsx unless you also change the script.

2. OPEN THE GUI
---------------
Double-click Start_Activity_Manager.bat.
Use the GUI to add, select, update and delete activities. You do not normally edit
ActivityList.xlsx directly; it is the record store.

If the launcher cannot find your Anaconda Python, open Anaconda Prompt, change to
this folder, and run:
  python event_mng_v7.py

The launcher can also be configured by setting ACTIVITY_MANAGER_PYTHON to the full
path of the Python executable in your Anaconda environment.

3. GUI DATE FIELDS
------------------
Due date: DD-MM-YYYY (required)
Due time: HH:MM in 24-hour format (required; e.g. 14:30 means 2:30 PM)
Reminder date: DD-MM-YYYY (optional; sends when today's calendar date equals it)
Daily reminders start: DD-MM-YYYY (optional; sends every day from this date inclusive
until the engineer's accepted reply status is Completed)

All date-only fields ignore Excel time portions such as 00:00:00. DueDate includes
the time and is used for due/overdue time checks and shown in the email.
If ReminderDate and DailyReminderStartDate both apply on the same day, only one
reminder is sent that day. LastReminderDate prevents same-day duplicate sends.
A one-time ReminderDate is not sent late if the application was not run on that date.

4. EMAIL AND OUTLOOK REQUIREMENTS
--------------------------------
- Windows computer.
- Classic Outlook desktop installed and configured with a mail profile.
- Each AdminMailID entered in the GUI must exist as an account in that Outlook profile.
  A shared mailbox that is only visible as a folder, but is not configured as an
  Outlook account, may not be selectable by this program.
- The program sends from the selected AdminMailID and puts ManagerEmail in CC.
- Completion replies are checked in the Inbox belonging to that AdminMailID account,
  not merely the Outlook default Inbox.
- The sender of a completion reply must match one of the AssignedTo addresses.
- The reply must contain one of these exact lines in its new reply text:
      Status: Completed
      Status: Not Completed Yet
      Status: In Progress
      Status: Delayed
  Keep ActivityID in the subject or include ActivityID: <id> in the reply.
- New Outlook is not supported by this pywin32/COM implementation.

5. INSTALLATION ON THE OTHER COMPUTER
-------------------------------------
Install/use Python 3.12 (Anaconda is acceptable). In Anaconda Prompt, change to this
folder and run:
  python -m pip install -r requirements.txt

If the computer has no internet, download compatible wheels for Python 3.12 and
Windows on another computer, transfer them by USB, then install from that folder:
  python -m pip install --no-index --find-links D:\wheels -r requirements.txt

Tkinter is normally included with standard Windows Python and Anaconda. win10toast
is optional; email reminders do not depend on it.

Run Check_Installation.bat for a basic dependency check. Then open Classic Outlook manually
once and sign in. Run Test_Outlook_Profile.py to list the accounts and confirm that each
AdminMailID has an accessible Delivery Inbox. This diagnostic sends no email.

6. WINDOWS TASK SCHEDULER
-------------------------
Create a daily task using the same Windows user account that has the configured
Outlook profile. Recommended settings:
- Select "Run only when user is logged on" for Outlook COM automation.
- Program/script: full path to Run_Daily_Reminders.bat
- Start in: the folder containing this application (the BAT also changes to its own
  folder, but setting Start in is still good practice).
- Set the trigger to the required daily time.

You can also use the full Python executable as Program/script, with:
  event_mng_v7.py --run
as arguments, and the application folder as "Start in".

7. FIRST TEST - DO NOT START WITH ALL REAL TASKS
------------------------------------------------
- Back up any existing ActivityList.xlsx before extracting/copying the new template.
- Start with one test activity assigned to your own test mailbox.
- Set AdminMailID to an account configured in Outlook.
- Set ManagerEmail to your own/test mailbox to verify CC.
- Set ReminderDate to today's date and click "Run reminders now" once.
- Check the Sent Items of the selected AdminMailID account and confirm From, To and CC.
- Reply from the AssignedTo mailbox with "Status: Completed" and keep ActivityID in
  the subject. Run the reminder job again and confirm CompletionStatus becomes
  Completed and no further reminder is sent.
- Also test a task with DailyReminderStartDate set to today. LastReminderDate ensures
  that running the job repeatedly on the same day does not send duplicate reminders.

8. IMPORTANT LIMITATIONS / OPERATION
------------------------------------
- Do not keep ActivityList.xlsx open in Excel while the application is writing to it.
- Do not run two copies of the scheduled job simultaneously.
- The program syntax and core date/schema/reply parsing have been checked, but actual
  Outlook delivery and mailbox permissions must be verified on the target PC.
- If Outlook is unavailable, the log records the error; the job cannot send or poll.
- Keep a periodic backup of ActivityList.xlsx and reminder_log.txt.
