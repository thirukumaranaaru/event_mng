@echo off
setlocal
cd /d "%~dp0"

REM Optional: set ACTIVITY_MANAGER_PYTHON to the full path of your Anaconda python.exe.
set "PYTHON_CMD="
if defined ACTIVITY_MANAGER_PYTHON set "PYTHON_CMD="%ACTIVITY_MANAGER_PYTHON%""
if not defined PYTHON_CMD if defined CONDA_PREFIX if exist "%CONDA_PREFIX%\python.exe" set "PYTHON_CMD="%CONDA_PREFIX%\python.exe""
if not defined PYTHON_CMD if exist "%USERPROFILE%\anaconda3\python.exe" set "PYTHON_CMD="%USERPROFILE%\anaconda3\python.exe""
if not defined PYTHON_CMD if exist "%USERPROFILE%\miniconda3\python.exe" set "PYTHON_CMD="%USERPROFILE%\miniconda3\python.exe""
if not defined PYTHON_CMD if exist "%LOCALAPPDATA%\anaconda3\python.exe" set "PYTHON_CMD="%LOCALAPPDATA%\anaconda3\python.exe""
if not defined PYTHON_CMD if exist "%LOCALAPPDATA%\miniconda3\python.exe" set "PYTHON_CMD="%LOCALAPPDATA%\miniconda3\python.exe""
if not defined PYTHON_CMD (
  where python >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  where py >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=py -3.12"
)

if not defined PYTHON_CMD (
  echo Python 3.12 was not found. Configure ACTIVITY_MANAGER_PYTHON or use Anaconda Prompt.
  exit /b 1
)
%PYTHON_CMD% event_mng_v7.py --run
exit /b %errorlevel%
