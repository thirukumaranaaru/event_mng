"""List Outlook accounts visible to this Windows user; sends no email."""
import sys
try:
    import win32com.client
except ImportError:
    print("pywin32 is not installed in this Python environment.")
    raise SystemExit(1)
try:
    app = win32com.client.Dispatch("Outlook.Application")
    accounts = app.Session.Accounts
    print(f"Outlook accounts found: {accounts.Count}")
    for index in range(1, accounts.Count + 1):
        account = accounts.Item(index)
        address = str(getattr(account, "SmtpAddress", "") or "(SMTP address unavailable)")
        try:
            store = account.DeliveryStore
            inbox = store.GetDefaultFolder(6)
            inbox_name = str(getattr(inbox, "Name", "Inbox"))
            print(f"{index}. {address} | Delivery Inbox: {inbox_name} | Accessible")
        except Exception as exc:
            print(f"{index}. {address} | Delivery Inbox unavailable: {exc}")
    print("\nCompare the AdminMailID values entered in the Activity Manager with the SMTP addresses above.")
except Exception as exc:
    print("Could not open the Outlook profile:", exc)
    print("Open Classic Outlook once, sign in, and run this script again.")
    raise SystemExit(2)
